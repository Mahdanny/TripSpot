const mongoose = require('mongoose');
const Schema = mongoose.Schema;



// Create Schema
const MessageSchema = new Schema({
    title: {
        type: String,
        required: true,
    },
    message: {
        type: String,
        required: true,
    },
    receiverUsername: {
        type: String,
        required: true
    },
    senderUsername: {
        type: String,
        required: true
    },
    receiverId: {
        type: String,
        required: true
    },
    senderId: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        default: Date.now
    }
});

module.exports = Message = mongoose.model('message', MessageSchema);