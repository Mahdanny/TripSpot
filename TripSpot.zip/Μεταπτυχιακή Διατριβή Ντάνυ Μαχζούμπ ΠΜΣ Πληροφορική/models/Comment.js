const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Create Schema
const CommentSchema = new Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    placeId: {
        type: String,
        required: true
    },
    placeName: {
        type: String,
        required: true
    },
    images: {
        type: [String]
    },
    stars: {
        type: String,
        required: true
    },
    accepted: {
        type: Boolean,
        default: false
    },
    creatorId: {
        type: String,
        required: true
    },
    creatorUsername: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        default: Date.now
    }
});

module.exports = Comment = mongoose.model('comment', CommentSchema);