const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Create Schema
const PlaceSchema = new Schema({
    name: {
        type: String,
        required: true,
        unique: true
    },
    category: {
        type: String,
        required: true,
    },
    images: {
        type: [],
        required: true
    },
    stars: {
        type: String,
        default: 'undefined'
    },
    coords: {
        type: [Number],
        index: '2d',
        required:true
    },
    country: {
        type: String,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    accepted: {
        type: Boolean,
        default: false
    },
    creatorId: {
        type: String,
        required: true
    },
    numberOfComments: {
        type: Number,
        default: 0
    },
        date: {
        type: Date,
        default: Date.now
    },
    ranking: {
        type: Number,
        default: 0
    }
});

module.exports = Place = mongoose.model('place', PlaceSchema);