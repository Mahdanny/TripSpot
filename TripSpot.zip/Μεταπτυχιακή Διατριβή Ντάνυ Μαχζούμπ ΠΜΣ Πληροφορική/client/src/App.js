import React, { Component } from 'react';
import AppNavbar from './components/AppNavbar';
import { Redirect } from 'react-router-dom';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import { Provider } from 'react-redux';
import store from './store';
import { loadUser } from './actions/authActions';

import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css';
import CategoriesList from './components/CategoriesList';
import PlacesList from './components/PlacesList';
import Home from './components/Home';
import RequestsList from './components/RequestsList';
import MessagesList from './components/MessagesList';
import FavoritesList from './components/FavoritesList';
import Logout from './components/auth/Logout';


class App extends Component {

    componentDidMount() {
        store.dispatch(loadUser());
    }

    render() {
        return (
            <Provider store={store}>
                <Router>
                <div className="App">
                    <AppNavbar />
                    <br />
                        <Switch>
                            <Route exact path="/" component={Home} />
                            <Route exact path="/Places" component={PlacesList} />
                            <Route exact path="/Favorites" component={FavoritesList} />
                            <Route exact path="/Requests" component={() =>
                                <RequestsList admin= "true" />} />
                            <Route exact path="/MyRequests" component={() =>
                                <RequestsList admin="false" />}  />
                            <Route exact path="/Categories" component={CategoriesList} />
                            <Route exact path="/Logout" component={Logout} />
                            <Route exact path="/MyMessages" component={MessagesList} />
                            <Route path="/*" render={() =>
                                <Redirect to={{ pathname: "/" }} />} />
                        </Switch>
                    </div>
                    </Router>
            </Provider>
        );
    }
}

export default App;
