import React, { Component } from 'react';
import StarRatings from 'react-star-ratings';

class Stars extends Component {
    constructor(props) {
        super(props);
        this.state = {
            stars: this.props.stars,
            selectable: this.props.selectable
        };
    }
    changeRating = (newRating, name) => {

        this.props.changeRating(String(newRating));
    }
    componentDidUpdate(prevProps) {
        if (this.props.stars !== prevProps.stars || this.props.selectable !== prevProps.selectable) {
            this.setState({
                stars: String(this.props.stars),
                selectable: this.props.selectable
            });
        }
        
    }
    render() {
        if (String(this.state.stars) === "undefined") return ((null));
        return (
            this.state.selectable ?
                <StarRatings 
                    rating={Number(this.state.stars)}
                    starRatedColor="gold"
                    changeRating={this.changeRating}
                    isSelectable={this.selectable}
                    starDimension="15px"
                    numberOfStars={5}
                    starSpacing="2px"
                    name='rating'
                />
                :
                <StarRatings 
                    rating={Number(this.state.stars)}
                    starRatedColor="gold"
                    starDimension="15px"
                    starSpacing="2px"
                    isSelectable={this.selectable}
                    numberOfStars={5}
                    name='rating'
                />
        );
    }
}

export default Stars;