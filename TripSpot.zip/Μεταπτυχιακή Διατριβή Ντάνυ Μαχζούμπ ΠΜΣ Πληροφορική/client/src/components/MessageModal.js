import React, { Component } from 'react';
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    Form,
    FormGroup,
    Label,
    Input,
    Alert,
    Row,
    Col,
    ModalFooter
} from 'reactstrap';
import { connect } from 'react-redux';
import { addMessage } from '../actions/messageActions';
import PropTypes from 'prop-types';
import { clearErrors } from '../actions/errorActions';

class MessageModal extends Component {
    constructor(props) {
        super(props);
        this.state = { modal: false, title: '',message: '' }
    }

    componentDidUpdate(prevProps) {
        const { error } = this.props;
        if (error !== prevProps.error) {
            if (error.id === 'MESSAGE_FAIL') {
                this.setState({ msg: error.msg.msg });
            } else {
                this.setState({ msg: null })
            }

        }
        else if (this.state.modal && prevProps.message !== this.props.message) {
            this.setState({ msg: null })
            this.toggle();
        }

    }

    toggle = () => {
        // Clear errors
        this.props.clearErrors();

        this.setState({
            modal: !this.state.modal,
            title: '',
            message: ''
        });
    }

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    onSubmit = e => {
        e.preventDefault();

        const newMessage = {
            title: this.state.title,
            message: this.state.message,
            senderUsername: this.props.username,
            receiverUsername: this.props.msg.senderUsername

        }

        //Add message via addMesssage action
        this.props.addMessage(newMessage);


    }

    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        return (
            <div>
                <Button color="dark" style={{ marginLeft: '1rem', marginTop: '0.3rem' }} onClick={this.toggle}> Show Message </Button>
                <Modal isOpen={this.state.modal} toggle={this.toggle} size='sm'>
                    <ModalHeader toggle={this.toggle}>
                        <Row>
                            <Col>
                                {this.props.msg.title}
                            </Col>
                            <Col>
                                {this.props.sent ? this.props.msg.senderUsername : this.props.msg.receiverUsername}
                            </Col>
                            <Col>
                               {this.props.createDate(this.props.msg.date)}
                            </Col>
                        </Row>
                    </ModalHeader>
                    <ModalBody>
                       <p> {this.props.msg.message} </p>
                    </ModalBody>
                    {this.props.sent ?
                        <ModalFooter>
                            {this.state.msg ? <Alert color="danger">{this.state.msg}</Alert> : null}
                            <Form onSubmit={this.onSubmit}>
                                <FormGroup>
                                    <Label for="title"> Tittle </Label>
                                    <Input type="text" name="title" id="title" placeholder="Add Title" onChange={this.onChange} />
                                    <Label for="message"> Message </Label>
                                    <Input type="textarea" name="message" id="message" placeholder="Add Message" onChange={this.onChange} />
                                    <Button color="dark" style={{ marginTop: '2rem' }} block >Reply</Button>
                                </FormGroup>
                            </Form>
                        </ModalFooter>
                        : null}
                </Modal>
            </div>
        );
    }
}

MessageModal.propTypes = {
    addMessage: PropTypes.func.isRequired,
    isAuthenticated: PropTypes.string,
    error: PropTypes.object.isRequired,
    clearErrors: PropTypes.func.isRequired,
    message: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    isAuthenticated: state.auth.isAuthenticated,
    message: state.message,
    error: state.error
});



export default connect(mapStateToProps, { addMessage, clearErrors })(MessageModal);