import React, { Component } from 'react';
import Map from './Map';
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    Form,
    FormGroup,
    Label,
    Input,
    Col,
    Alert
} from 'reactstrap'; 
import Dropzone from 'react-dropzone'
//import Location from './location.component';
//import Map from './map.component';
import Image from 'react-bootstrap/Image';
import { connect } from 'react-redux';
import { addPlace } from '../actions/placeActions';
import { getCategories } from '../actions/categoryActions';
import PropTypes from 'prop-types';
import { clearErrors } from '../actions/errorActions';

const imageMaxSize = 1024 * 1024;
const fileTypes = 'image/x-png, image/png, image/jpg,image/jpeg';
const fileTypesArray = fileTypes.split(",").map((x) => { return x.trim() })

class PlaceModal extends Component {
    constructor(props) {
        super(props);
        this.state = { modal: false, name: '', category: '', images: [], address: '', country: '', city: '', coords: [22.727539, 36.983810],del:[]}
    }

    componentDidMount() {
        this.props.getCategories();
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.category !== this.props.category && this.props.category.categories.length !== 0) this.setState({ category: this.props.category.categories[0].name })
        const { error } = this.props;
        if (error !== prevProps.error) {
            if (error.id === 'PLACE_FAIL') {
                this.setState({ msg: error.msg.msg });
            } else {
                this.setState({ msg: null })
            }

        }
        else if (this.state.modal && prevProps.place !== this.props.place) {
            this.setState({ msg: null })
            this.toggle();
        }
    }
    toggle = () => {
        // Clear errors
        this.props.clearErrors();

        this.setState({
            modal: !this.state.modal, name: '', category: this.props.category.categories[0].name, images: [], address: '', country: '', city: '', coords: [22.727539, 36.983810], del: []
        });
    }

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }
    onChangeCoords = (lngLat)=>{
        this.setState({ coords: [lngLat.lng, lngLat.lat] })
    }
    onSubmit = e => {
        e.preventDefault();

        const newPlace = {
            name: this.state.name,
            category: this.state.category,
            images: this.state.images,
            country: this.state.country,
            city: this.state.city,
            coords: this.state.coords,
        }

        //Add category via addPlace action
        this.props.addPlace(newPlace);

    }
    //Remove Image
    removeImage = (image) => {
        if (String(image.name) === "undefined") this.setState({
            del: this.state.del.concat([image])
        });
        this.setState({
           images: this.state.images.filter(img => img.src !== image.src)
        });
    }
    //Return images
    renderImages=() =>{
        const { images } = this.state;
        const style = {
            width: "100%",
            height: " 100%",
            backgroundPosition: "50% 50%",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
        }
        var x = 0;
        return images.map((image) => {
            return (
                <Col style={{ width: "30%", height: "30%" }} key={"col" + (x++)}>
                    <Image src={image.src} style={style} rounded />
                        <Button color='green' onClick={() => this.removeImage(image)}
                            style={{
                                backgroundColor: "transparent", borderColor: "transparent",
                                position: 'absolute', color: 'red', top: -5, right: 5
                            }}>
                        X
            </Button>
                </Col>
            );
        })

    }
    //Verify that the file is image
    verifyFile = (file, x) => {
        if (file) {
            const current = file;
            const currentType = current.type;
            const currentSize = current.size;
            if (currentSize > imageMaxSize) {
                this.setState({
                    formError: this.state.formError +
                        currentSize + " bytes is too large(file number " + x + ")!"
                });
                return false;
            }
            if (!fileTypesArray.includes(currentType)) {
                this.setState({
                    formError: this.state.formError +
                        "Only image files are allowed(file number " + x + ")"
                });
                return false;
            }
            return true;
        }
    }
    //Upload image
    onDrop=(accepted, rejected) =>{
        var x = 1;
        if (rejected) {
            for (const current of rejected) this.verifyFile(current, x++);
        }
        if (accepted) {
            if (accepted.length + this.state.images.length > 1) {
                alert("Only 1 image per place is allowed!");
                return;
            }
            for (const current of accepted) {
                const isVerified = this.verifyFile(current, x++);
                if (isVerified) {
                    const reader = new FileReader();
                    reader.addEventListener("load", () => {
                        const res = reader.result;
                        current['src'] = res;
                        this.setState({
                            images: this.state.images.concat(current)
                        });
                    }, false);
                    reader.readAsDataURL(current);
                }
            }
        }
    }

    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        const { categories } = this.props.category;
        return (
            <div>
                {this.props.isAuthenticated === 'true' ? <Button color="dark" style={{ marginLeft: '2rem', marginBottom: '2rem' }}  onClick={this.toggle}> Add Place </Button> : null}
                <Modal isOpen={this.state.modal} toggle={this.toggle} size="lg">
                    <ModalHeader toggle={this.toggle}> Propose a place </ModalHeader>
                    <ModalBody>
                        {this.state.msg ? <Alert color="danger">{this.state.msg}</Alert> : null}
                        <Form onSubmit={this.onSubmit}>
                            <FormGroup>
                                {this.renderImages(true)}
                                <Dropzone onDrop={this.onDrop}
                                    accept={fileTypes} multiple maxSize={imageMaxSize}>
                                    {({
                                        getRootProps,
                                        getInputProps
                                    }) => {
                                        return (
                                            <div {...getRootProps()}>
                                                <input {...getInputProps()} />
                                                <p> {"Drop image here or click to upload "}</p>
                                            </div>
                                        );
                                    }}
                                </Dropzone>
                                <Label for="name"> Name </Label>
                                <Input type="text" name="name" id="name" placeholder="Add Name" onChange={this.onChange} />
                                <Label for="category"> Category </Label>
                                <select value={this.state.category} name="category" id="category" onChange={this.onChange} style={{
                                    width: "100%",
                                    textAlign: "center", backgroundColor: "transparent"
                                }}>
                                    {categories.map(({ name }) => (
                                        <option key={name} value={name}>{name}</option>
                                    ))}
                                </select>
                                <Label for="country"> Country </Label>
                                <Input type="text" name="country" id="country" placeholder="Add Country" onChange={this.onChange} />
                                <Label for="city"> City </Label>
                                <Input type="text" name="city" id="city" placeholder="Add City" onChange={this.onChange} />
                                <Label for="map"> Drag the marker to the location </Label>
                                <Map sz={{ height: "40vh", width: "50vw" }}  id="map" onChangeCoords={this.onChangeCoords} coords={this.state.coords} draggable = 'true' />
                                <Button color="dark" style={{ marginTop: '2rem' }} block >Propose a place</Button>
                            </FormGroup>
                        </Form>
                    </ModalBody>
                </Modal>
            </div>
        );
    }
}

PlaceModal.propTypes = {
    addPlace: PropTypes.func.isRequired,
    isAuthenticated: PropTypes.string,
    getCategories: PropTypes.func.isRequired,
    category: PropTypes.object.isRequired,
    clearErrors: PropTypes.func.isRequired,
    error: PropTypes.object.isRequired,
    place: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    isAuthenticated: state.auth.isAuthenticated,
    category: state.category,
    error: state.error,
    place: state.place
});



export default connect(mapStateToProps, { addPlace, getCategories, clearErrors })(PlaceModal);