import React, { Component } from 'react';
import { Container, ListGroup, ListGroupItem, Col, Row, Table, Alert } from 'reactstrap';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import { connect } from 'react-redux';
import { getFavorites } from '../actions/favoriteActions';
import { getFavoritesDetails } from '../actions/placeActions';
import PropTypes from 'prop-types';
import Image from 'react-bootstrap/Image';
import CommentsModal from './CommentsModal';
import { getComments } from '../actions/commentActions';
import Pagination from "react-js-pagination";
import 'bootstrap/dist/css/bootstrap.min.css';


class FavoritesList extends Component {
    constructor(props) {
        super(props);
        this.state = {  currentPage: 1, pageCount: 1 }
        
    }
    componentDidMount(){
        this.props.getFavorites();
        this.props.getComments();
    }
    componentDidUpdate(prevProps, prevState) {

        if (this.props.place !== prevProps.place) {
            const { places } = this.props.place;
            this.setState({
                pageCount: Math.ceil(places.length / 5.0),
                currentPage: this.state.currentPage > Math.ceil(places.length / 5.0) ? 1 : this.state.currentPage
            })
        }

        if (prevProps.favorite !== this.props.favorite ) {
            this.props.getFavoritesDetails({
                ids: this.props.favorite.favorites.map((favorite) =>  favorite.placeId )
            })
        }
    }

    // Change Page Pagination
    handlePageChange = (pageNumber) => {
        this.setState({ currentPage: pageNumber });
    }

    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        const { places } = this.props.place;
        const { comments } = this.props.comment;
        const favoritiesPagination = places.length < (5 * (this.state.currentPage - 1)) + 5 ? places.slice(5 * (this.state.currentPage - 1), places.length)
            : places.slice(5 * (this.state.currentPage - 1), (5 * (this.state.currentPage - 1)) + 5)
        if (this.props.isAuthenticated === "false") return (<Alert color="danger">You have to  login to access this page</Alert> );
        return (
            <Container>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }} >
                    <Pagination
                        itemClass="page-item"
                        linkClass="page-link"
                        hideDisabled
                        activePage={this.state.currentPage}
                        itemsCountPerPage={5}
                        totalItemsCount={places.length}
                        pageRangeDisplayed={5}
                        onChange={this.handlePageChange}
                    />
                </div>
                <ListGroup>
 <TransitionGroup className="place-list">
                        {favoritiesPagination.map((place ) => (
                            <CSSTransition   key={place._id} timeout={500} classNames='fade'>
                                <ListGroupItem key={place._id} style={{ textAlign: "center" }} >
                                    <Container>
                                    <Row >
                                        <Col sm={3}
                                            key={"col" + place.images[0]}>
                                            <Image style={{ width: "100%", height: "90%" }}
                                                src={place.images[0]} rounded />
                                        </Col>
                                        <Col sm={9} >
                                                <Table striped bordered hover variant="dark"
                                                    style={{ width: "100%", height: "90%", overflow:"auto" }} repsonsive="sm">
                                                <thead>
                                                    <tr >
                                                  <th style={{ width: "20%", fontSize:"3vh" }}>Name</th>
                                                            <td style={{ fontSize: "2.5vh" }}>{place.name}</td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                            <th style={{ width: "20%", fontSize: "3vh" }}>Category</th>
                                                            <td style={{ fontSize: "2.5vh" }}>{place.category}</td>
                                                    </tr>
                                                    <tr >
                                                            <th style={{ width: "20%", fontSize: "3vh" }}>Country</th>
                                                            <td style={{ fontSize: "2.5vh" }}>{place.country}</td>
                                                    </tr>
                                                    <tr >
                                                            <th style={{ width: "20%", fontSize: "3vh" }}>City</th>
                                                            <td style={{ fontSize: "2.5vh" }}>{place.city}</td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </Col>
                                        </Row>
                                        <CommentsModal place={place} comments={comments.filter((comment) => place._id === comment.placeId)} favorites={this.props.favorite.favorites.map((favorite) => favorite.placeId)} />
                                        </Container>
                                </ListGroupItem>
                            </CSSTransition>
                        ))}
                    </TransitionGroup>
                </ListGroup>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: "1rem" }} >
                    <Pagination
                        itemClass="page-item"
                        linkClass="page-link"
                        hideDisabled
                        activePage={this.state.currentPage}
                        itemsCountPerPage={5}
                        totalItemsCount={places.length}
                        pageRangeDisplayed={5}
                        onChange={this.handlePageChange}
                    />
                </div>
            </Container>
        );
    }
}
FavoritesList.propTypes = {
    getFavorites: PropTypes.func.isRequired,
    getFavoritesDetails: PropTypes.func.isRequired,
    getComments: PropTypes.func.isRequired,
    place: PropTypes.object.isRequired,
    isAuthenticated: PropTypes.string,
    favorite: PropTypes.object.isRequired,
    comment: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    place: state.place,
    favorite: state.favorite,
    comment: state.comment,
    isAuthenticated: state.auth.isAuthenticated
});



export default connect(mapStateToProps, { getComments,getFavorites, getFavoritesDetails })(FavoritesList);