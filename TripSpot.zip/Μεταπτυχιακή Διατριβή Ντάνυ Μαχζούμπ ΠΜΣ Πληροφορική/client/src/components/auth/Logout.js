import  { Component } from 'react';
import { logout } from '../../actions/authActions';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

class Logout extends Component {
    componentDidMount() {
        this.props.logout();
        this.props.history.push('/');
    }
    render() {
        return (null);
    }
}

Logout.propTypes = {
    logout: PropTypes.func.isRequired
}

export default connect(null, { logout })(Logout);