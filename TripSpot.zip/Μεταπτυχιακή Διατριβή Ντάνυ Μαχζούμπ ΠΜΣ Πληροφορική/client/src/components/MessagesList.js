import React, { Component } from 'react';
import { Container, Alert,Table } from 'reactstrap';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { getMessages, addMessage } from '../actions/messageActions';
import Tabs from 'react-bootstrap/Tabs'
import Tab from 'react-bootstrap/Tab'
import MessageModal from './MessageModal'
import SendMessageModal from './SendMessageModal'
import Pagination from "react-js-pagination";
import 'bootstrap/dist/css/bootstrap.min.css';




class MessagesList extends Component {
    constructor(props) {
        super(props);
        this.state = { key: 'Received' ,currentPage: 1, pageCount: 1,userPropsChanged:false,messagePropsChanged:false }
    }

    componentDidMount() {
        this.props.getMessages();
    }

    componentDidUpdate(prevProps,prevState) {
        if (this.props.message !== prevProps.message) this.setState({ messagePropsChanged: true })
        if (this.props.user !== prevProps.user) this.setState({ userPropsChanged: true })
        if (this.state.userPropsChanged === true && this.props.message !== prevProps.message) {
            const { messages } = this.props.message;
            if (this.state.key === "Received") {
                const receivedMessages = messages.filter(message => message.receiverId === this.props.user._id)
                this.setState({
                    pageCount: Math.ceil(receivedMessages.length / 5.0),
                    currentPage: this.state.currentPage > Math.ceil(receivedMessages.length / 5.0) ? 1 : this.state.currentPage

                })
            }
            else {
                const sentMessages = messages.filter(message => message.senderId === this.props.user._id)
                this.setState({
                    pageCount: Math.ceil(sentMessages.length / 5.0),
                    currentPage: this.state.currentPage > Math.ceil(sentMessages.length / 5.0) ? 1 : this.state.currentPage

                })
            }
        }
    }

    onSelect = (key) => {
        this.setState({ key: key });
        const { messages } = this.props.message;
        if (key === "Received") {
            const receivedMessages = messages.filter(message => message.receiverId === this.props.user._id)
            this.setState({
                pageCount: Math.ceil(receivedMessages.length / 5.0),
                currentPage: 1

            })
        }
        else {
            const sentMessages = messages.filter(message => message.senderId === this.props.user._id)
            this.setState({
                pageCount: Math.ceil(sentMessages.length / 5.0),
                currentPage: 1

            })
        }
    }

    // Change Page Pagination
    handlePageChange = (pageNumber) => {
        this.setState({ currentPage: pageNumber });
    }


    // Convert MongoDB date to readable date
    createDate = (date) => {
        var created_date = new Date(date);

        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var year = created_date.getFullYear();
        var month = months[created_date.getMonth()];
        var day = created_date.getDate();
        var hour = created_date.getHours();
        var min = created_date.getMinutes();
        var sec = created_date.getSeconds();
        return  day + ',' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec; 
    }

    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        if (this.props.isAuthenticated === "false") return (<Alert color="danger">You have to  login to access this page</Alert>);
        const { messages } = this.props.message;
        const receivedMessages = messages.filter(message => message.receiverId === this.props.user._id)
        const receiverMessagesPagination = receivedMessages.length < (5 * (this.state.currentPage - 1)) + 5 ? receivedMessages.slice(5 * (this.state.currentPage - 1), receivedMessages.length)
            : receivedMessages.slice(5 * (this.state.currentPage - 1), (5 * (this.state.currentPage - 1)) + 5)
        const sentMessages = messages.filter(message => message.senderId === this.props.user._id)
        const sentMessagesPagination = sentMessages.length < (5 * (this.state.currentPage - 1)) + 5 ? sentMessages.slice(5 * (this.state.currentPage - 1), sentMessages.length)
            : sentMessages.slice(5 * (this.state.currentPage - 1), (5 * (this.state.currentPage - 1)) + 5)
        return (
            <Container>
                <SendMessageModal username={this.props.user.username} receiverUsername ='Add a receiver'/>
                <Tabs activeKey={this.state.key} onSelect={this.onSelect}>
                    <Tab eventKey="Received" title="Received">
                        <Table striped bordered hover variant="dark"
                            style={{ overflow: "auto" }} repsonsive="sm">
                            <thead>
                                <tr>
                                    <th>Sender's Name</th>
                                    <th>Title</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {receiverMessagesPagination.map((message) => (
                                    <tr>
                                        <td>{message.senderUsername}</td>
                                        <td>{message.title}</td>
                                        <td>{this.createDate(message.date)}</td>
                                        <td> <MessageModal msg={message} username={this.props.user.username} createDate={this.createDate} sent={true} /> </td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: "1rem" }} >
                            <Pagination
                                itemClass="page-item"
                                linkClass="page-link"
                                hideDisabled
                                activePage={this.state.currentPage}
                                itemsCountPerPage={5}
                                totalItemsCount={receivedMessages.length}
                                pageRangeDisplayed={5}
                                onChange={this.handlePageChange}
                            />
                        </div>
                    </Tab>
                    <Tab eventKey="Sent" title="Sent">
                        <Table striped bordered hover variant="dark"
                            style={{ overflow: "auto" }} repsonsive="sm">
                            <thead>
                                <tr>
                                    <th>Receiver's Name</th>
                                    <th>Title</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>

                                {sentMessagesPagination.map((message) =>(
                                    <tr>
                                                <td>{message.receiverUsername}</td>
                                                <td>{message.title}</td>
                                        <td>{this.createDate(message.date)}</td>
                                        <td> <MessageModal msg={message} username={this.props.user.username} createDate={this.createDate} sent={false} /> </td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: "1rem" }} >
                            <Pagination
                                itemClass="page-item"
                                linkClass="page-link"
                                hideDisabled
                                activePage={this.state.currentPage}
                                itemsCountPerPage={5}
                                totalItemsCount={sentMessages.length}
                                pageRangeDisplayed={5}
                                onChange={this.handlePageChange}
                            />
                        </div>
                    </Tab>
                </Tabs>
            </Container>
        );
    }
}

MessagesList.propTypes = {
    getMessages: PropTypes.func.isRequired,
    addMessage: PropTypes.func.isRequired,
    message: PropTypes.object.isRequired,
    isAuthenticated: PropTypes.string,
    user: PropTypes.object.isRequired,
}

const mapStateToProps = state => ({
    message: state.message,
    isAuthenticated: state.auth.isAuthenticated,
    user: state.auth.user
});



export default connect(mapStateToProps, { getMessages, addMessage })(MessagesList);