import React, { Component, Fragment } from 'react';
import {
    Navbar, 
    NavbarBrand, 
    Nav, 
    NavItem, 
    NavLink,
    Container,
    Dropdown, DropdownItem, DropdownToggle, DropdownMenu
} from 'reactstrap';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import RegisterModal from './auth/RegisterModal';
import LoginModal from './auth/LoginModal';

class AppNavbar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false
        }
    }
    toggle = () => {
        this.setState({
            isOpen: !this.state.isOpen
        });
    };

    render() {
        const { isAuthenticated, user, isAdmin } = this.props.auth;
        if (isAuthenticated === "undefined") return ((null));
        const authLinks = (
            <Fragment>
                <NavItem>
                    <Dropdown nav isOpen={this.state.isOpen} toggle={this.toggle}>
                        <DropdownToggle nav caret>
                            <span className="navbar-text mr-3">
                                <strong> {user ? `${user.username}` : ''} </strong>
                            </span>
                        </DropdownToggle>
                        <DropdownMenu>
                            <DropdownItem href="/MyRequests">My Requests</DropdownItem>
                            <DropdownItem href="/MyMessages">My Messages</DropdownItem>
                            <DropdownItem divider />
                            <DropdownItem href="/Logout">Logout</DropdownItem>
                        </DropdownMenu>
                    </Dropdown>
                </NavItem>
            </Fragment> 
            );

        const guestLinks = (
            <Fragment>
                <NavItem>
                    <LoginModal />
                </NavItem>
                <NavItem>
                    <RegisterModal />
                </NavItem>
            </Fragment> 
            );

        return (
           <div>
                <Navbar color='dark' dark expand="sm" className="mb-5">
                    <Container>
                        <NavbarBrand href="/">TripSpot</NavbarBrand>                    
                        <NavLink href="/Places">Places</NavLink>
                        {isAuthenticated === "true" ? <NavLink href="/Favorites">Favorites</NavLink> : null}
                        {isAdmin === true ? <NavLink href="/Requests">Requests</NavLink> : null}
                        {isAdmin === true ? <NavLink href="/Categories">Categories</NavLink> : null}
                            <Nav className="ml-auto" navbar>
                                {isAuthenticated==="true" ? authLinks : guestLinks}
                            </Nav>
                    </Container>
                </Navbar>
           </div>
        );
    }
}

AppNavbar.propTypes = {
    auth: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    auth: state.auth
});



export default connect(mapStateToProps, null)(AppNavbar);