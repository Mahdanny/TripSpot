import React, { Component } from 'react';
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    Form,
    FormGroup,
    Label,
    Input
} from 'reactstrap';
import { connect } from 'react-redux';
import Map from './Map';
import Select from 'react-select';


class SearchModal extends Component {
    constructor(props) {
        super(props);
        this.state = { modal: false, name: '', country: '', city: '', categories: this.props.categories.map((category) => category.name), coords: [22.727539, 36.983810], km: 0}
    }

    toggle = () => {
        this.setState({
            modal: !this.state.modal,
            name: '', country: '', city: '', categories: this.props.categories.map((category) => category.name), coords: [22.727539, 36.983810], km: 0
        });
    }

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    onChangeCoords = (lngLat) => {
        this.setState({ coords: [lngLat.lng, lngLat.lat] })
    }

    onSubmit = e => {
        e.preventDefault();

        const newSearch = {
            name: this.state.name,
            country: this.state.country,
            city: this.state.city,
            categories: this.state.categories,
            coords: this.state.coords,
            km: this.state.km === 0 ? Number.MAX_VALUE : this.state.km ,
        }
        //Search
        this.props.Search(newSearch);
        //Close modal
        this.toggle();
    }
    renderSelectOptions = () => {
        return this.props.categories.map((category) =>  ({ label: category.name, value: category.name }) );
    }
    onChangeOptions = (categories) => {
        this.setState({
            categories: categories.length === 0 ? this.props.categories.map((category) => category.name):categories.map((category) => category.value)
        })
    }
 
    render() {
        const options = this.renderSelectOptions();
        return (
            <div>
                <Button color="dark" style={{ marginLeft: '2rem', marginBottom: '2rem'  }}  onClick={this.toggle}> Search Place </Button>
                <Modal isOpen={this.state.modal} toggle={this.toggle}>
                    <ModalHeader toggle={this.toggle}> Search options </ModalHeader>
                    <ModalBody>
                        <Form onSubmit={this.onSubmit}>
                            <FormGroup>
                                <Label for="name"> Name </Label>
                                <Input type="text" name="name" id="name" placeholder="Add Name" onChange={this.onChange} />
                                <Label for="country"> Country </Label>
                                <Input type="text" name="country" id="country" placeholder="Add Country" onChange={this.onChange} />
                                <Label for="city"> City </Label>
                                <Input type="text" name="city" id="city" placeholder="Add City" onChange={this.onChange} />
                                <Label for="categories"> Categories </Label>
                                <Select options={options} placeholder="Select Categories"
                                    style={{ borderColor: "#00a2ed" }} required id="categories" onChange={this.onChangeOptions} isMulti
                                   />
                                <Map sz={{ height: "30vh", width: "30vw" }} id="map" onChangeCoords={this.onChangeCoords} coords={this.state.coords} draggable='true' />
                                <Label for="km"> Km </Label>
                                <Input type="number" name="km" id="km" placeholder="0" min="0" onChange={this.onChange} />
                                <Button color="dark" style={{ marginTop: '2rem' }} block >Search</Button>
                            </FormGroup>
                        </Form>
                    </ModalBody>
                </Modal>
            </div>
        );
    }
}

const mapStateToProps = state => ({
 
});



export default connect(mapStateToProps, {  })(SearchModal);