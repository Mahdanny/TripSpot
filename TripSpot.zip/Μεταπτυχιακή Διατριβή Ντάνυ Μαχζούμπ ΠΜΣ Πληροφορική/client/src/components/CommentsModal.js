import React, { Component } from 'react';
import Map from './Map';
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    Form,
    FormGroup,
    Label,
    Input,
    Col,
    ModalFooter,
    Row,
    ListGroup,
    ListGroupItem,
    Alert
} from 'reactstrap';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import Dropzone from 'react-dropzone'
import Image from 'react-bootstrap/Image';
import { connect } from 'react-redux';
import { addComment } from '../actions/commentActions';
import PropTypes from 'prop-types';
import Stars from './Stars';
import SendMessageModal from './SendMessageModal'
import { addFavorite, deleteFavorite } from '../actions/favoriteActions';
import Heart from "react-animated-heart";
import { clearErrors } from '../actions/errorActions';
import Pagination from "react-js-pagination";
import 'bootstrap/dist/css/bootstrap.min.css';

const imageMaxSize = 1024 * 1024;
const fileTypes = 'image/x-png, image/png, image/jpg,image/jpeg';
const fileTypesArray = fileTypes.split(",").map((x) => { return x.trim() })

class CommentModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modal: false, title: '', images: [], description: '', del: [], stars: this.props.place.stars === "undefined" ? "1.0" : Math.round(this.props.place.stars),
            isClick: this.props.favorites.includes(this.props.place._id), currentPage: 1, pageCount: 1
        }
    }

    componentDidUpdate(prevProps) {
        if (this.props.comments !== prevProps.comments) {
            const comments = this.props.comments;
            this.setState({
                pageCount: Math.ceil(comments.length / 5.0),
                currentPage: this.state.currentPage > Math.ceil(comments.length / 5.0) ? 1 : this.state.currentPage
            })
        }
        const { error } = this.props;
        if (error !== prevProps.error) {
            if (error.id === 'COMMENT_FAIL') {
                this.setState({ msg: error.msg.msg });
            } else {
                this.setState({ msg: null })
            }

        }
        else if (this.state.modal && prevProps.comment !== this.props.comment) {
            this.setState({ msg: null })
            this.toggle();
        }

    }

    // Change Page Pagination
    handlePageChange = (pageNumber) => {
        this.setState({ currentPage: pageNumber });
    }
 
   
    toggle = () => {
        // Clear errors
        this.props.clearErrors();

        this.setState({
            modal: !this.state.modal, title: '', images: [], description: '', del: [], stars: this.props.place.stars==="undefined" ? "1.0" : Math.round(this.props.place.stars)
        });
    }

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });

    }
    onSubmit = e => {
        e.preventDefault();
        const newComment = {
            title: this.state.title,
            description: this.state.description,
            images: this.state.images,
            stars: this.state.stars,
            creatorUsername: this.props.user.username,
            placeId: this.props.place._id,
            placeName: this.props.place.name
        }

        //Add comment via addComment action
        this.props.addComment(newComment);
    }

    // Stars
    changeRating = (newRating) => {
        this.setState({
            stars: String(newRating)
        });
    }

    // Heart
    onClick = () => {
        if (this.state.isClick) {
            this.toggle();
            this.props.deleteFavorite(this.props.place._id);
        }
        else {
            this.props.addFavorite({placeId: this.props.place._id });
        }
        this.setState({ isClick: !this.state.isClick });
    }

    //Remove Image
    removeImage = (image) => {
        if (String(image.name) === "undefined") this.setState({
            del: this.state.del.concat([image])
        });
        this.setState({
            images: this.state.images.filter(img => img.src !== image.src)
        });
    }
    //Return images at add comment
    renderImages = () => {
        const { images } = this.state;
        const style = {
            width: "100%",
            height: "100%",
            backgroundPosition: "50% 50%",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
        }
        var x = 0;
        return images.map((image) => {
            return (

                <Col style={{ width: "30%", height: "30%" }}  key={"col" + (x++)}>
                    <Image src={image.src} style={style} rounded />
                    <Button color='green' onClick={() => this.removeImage(image)}
                        style={{
                            backgroundColor: "transparent", borderColor: "transparent",
                            position: 'absolute', color: 'red', top: -5, right: 5
                        }}>
                        X
            </Button>
                </Col>
            );
        })

    }
    //Return images at get comments
    renderImagesComments = (comment) => {
        const style = {
            width: "70%",
            height: "70%",
            backgroundPosition: "50% 50%",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
        }
        return comment.images.map((image) => {
            return (

                <Col style={{ width: "30%", height: "30%" }} key={"col" +image}>
                    <Image src={image} style={style} rounded />
                </Col>
            );
        })

    }
    //Verify that the file is image
    verifyFile = (file, x) => {
        if (file) {
            const current = file;
            const currentType = current.type;
            const currentSize = current.size;
            if (currentSize > imageMaxSize) {
                this.setState({
                    formError: this.state.formError +
                        currentSize + " bytes is too large(file number " + x + ")!"
                });
                return false;
            }
            if (!fileTypesArray.includes(currentType)) {
                this.setState({
                    formError: this.state.formError +
                        "Only image files are allowed(file number " + x + ")"
                });
                return false;
            }
            return true;
        }
    }

    //Upload image
    onDrop = (accepted, rejected) => {
        var x = 1;
        if (rejected) {
            for (const current of rejected) this.verifyFile(current, x++);
        }
        if (accepted) {
            if (accepted.length + this.state.images.length > 3) {
                alert("Only 3 images per place is allowed!");
                return;
            }
            for (const current of accepted) {
                const isVerified = this.verifyFile(current, x++);
                if (isVerified) {
                    const reader = new FileReader();
                    reader.addEventListener("load", () => {
                        const res = reader.result;
                        current['src'] = res;
                        this.setState({
                            images: this.state.images.concat(current)
                        });
                    }, false);
                    reader.readAsDataURL(current);
                }
            }
        }
    }
    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        const comments = this.props.comments;
        const commentsPagination = comments.length < (5 * (this.state.currentPage - 1)) + 5 ? comments.slice(5 * (this.state.currentPage - 1), comments.length)
            : comments.slice(5 * (this.state.currentPage - 1), (5 * (this.state.currentPage - 1)) + 5)
        const style = {
            width: "80%",
            height: " 80%",
            backgroundPosition: "50% 50%",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
        }
        return (
            <div>
                <Row> <Button color="dark" style={{ marginBottom: '2rem' }} onClick={this.toggle}> Show comments </Button>
                    &nbsp; &nbsp; &nbsp; <Stars selectable={false} stars={this.props.place.stars} /> </Row>

                <Modal isOpen={this.state.modal} toggle={this.toggle} size='xl'>
                    <ModalHeader toggle={this.toggle}>
                        <Row>
                            <Col  style={{ float: "left", width: "50%" }}>
                                <Row>
                                    
                            <h1 style={{fontSize:"1.5vw "}} >
                                        {this.props.place.name} 

                                        </h1>
                                    
                                </Row>
                                <Row >
                                    
                                        <Image src={this.props.place.images[0]} style={style} rounded />
                                        
                                      
                                </Row>
                                <Row >
                                    < Col sm={7}>
                                        <Stars id="stars" selectable={false} stars={this.props.place.stars} /> 
                                        </ Col>
                                    < Col sm={3} style={{ marginTop: "-2rem" }} >
                                        {this.props.isAuthenticated === 'true' ? <div > < Heart isClick={this.state.isClick} onClick={this.onClick} /> </div> : null}
                                    </Col>
                                </Row>
                        </Col>
                         <Col style={{ float: "left", width: "50%" }}>
                         <h1 style={{ fontSize: "1.5vw" }}>
                            {this.props.place.city  + ', ' + this.props.place.country }
                            </h1>
                            <Map sz = {{ height: "27vh", width: "30vw" }} draggable='false'  coords={ this.props.place.coords }/> 
                        </Col>
                        </Row>
                    </ModalHeader>
                    <ModalBody>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center'}} >
                            <Pagination
                                itemClass="page-item"
                                linkClass="page-link"
                                hideDisabled
                                activePage={this.state.currentPage}
                                itemsCountPerPage={5}
                                totalItemsCount={comments.length}
                                pageRangeDisplayed={5}
                                onChange={this.handlePageChange}
                            />
                        </div>
                        <ListGroup>
                            <TransitionGroup className="comment-list">
                                {commentsPagination.map((comment) => (
                                    <CSSTransition key={comment._id} timeout={500} classNames="fade">
                                        <ListGroupItem>
                                            <Row style={{ display: "flex" }}>
                                                <h1 style={{ fontSize: "1.5vw" }}> {comment.title} </h1>  &nbsp; &nbsp; &nbsp; 
                                                <Stars  selectable={false} stars={comment.stars} />
                                                {this.props.isAuthenticated === 'true' ? <div style={{ marginLeft: "auto" }}> 
                                                    <SendMessageModal commentId={ comment._id} username={this.props.user.username} receiverUsername={comment.creatorUsername} /> </div>  : <h4  style={{ fontSize: "1.5vw", marginLeft: "auto" }}> {comment.creatorUsername}</h4>}
                                            </Row>
                                            <Row>
                                            <Col>
                                                <Row>
                                                { this.renderImagesComments(comment)}
                                                 </Row>
                                                </Col>
                                                <Col>
                                                    <p style={{ fontSize: "1vw", marginLeft: "1rem" }}> {comment.description} </p>
                                                    </Col>
                                        </Row>
                                        </ListGroupItem>
                                    </CSSTransition>
                                ))}
                            </TransitionGroup>
                        </ListGroup>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: "1rem" }} >
                            <Pagination
                                itemClass="page-item"
                                linkClass="page-link"
                                hideDisabled
                                activePage={this.state.currentPage}
                                itemsCountPerPage={5}
                                totalItemsCount={comments.length}
                                pageRangeDisplayed={5}
                                onChange={this.handlePageChange}
                            />
                        </div>
                    </ModalBody>
                    {this.props.isAuthenticated === 'true' ?
                        <ModalFooter>
                            {this.state.msg ? <Alert color="danger">{this.state.msg}</Alert> : null}
                            <Form onSubmit={this.onSubmit} style={{ width: '100%' }}>
                                <FormGroup>
                                    <Row>
                                        <Col>
                                            <Label for="title"> Title </Label>
                                            <Input type="text" name="title" id="title" placeholder="Add Title" onChange={this.onChange} />
                                            <span />
                                                <Row>
                                                        {this.renderImages()}
                                                </Row>
                                            <Dropzone onDrop={this.onDrop}
                                                accept={fileTypes} multiple maxSize={imageMaxSize}>
                                                {({
                                                    getRootProps,
                                                    getInputProps
                                                }) => {
                                                    return (
                                                        <div {...getRootProps()}>
                                                            <input {...getInputProps()} />
                                                            <p> {"Drop up to 3 images here or click to upload "}</p>
                                                        </div>
                                                    );
                                                }}
                                            </Dropzone>
                                        </Col>
                                        <Col>
                                            <Label for="description"> Comment </Label>
                                            <Input type="textarea" name="description" id="description" placeholder="Add Comment" onChange={this.onChange} />
                                            <Label for="stars"> Rate this place </Label>  &nbsp; &nbsp; &nbsp; 
                                            <Stars id="stars" selectable={true} changeRating={this.changeRating} stars={ this.state.stars} />
                                            <Button color="dark" style={{ marginTop: '2rem' }} block >Submit a comment</Button>
                                        </Col>
                                    </Row>
                                </FormGroup>
                            </Form>
                        </ModalFooter> : null}
                </Modal>
            </div>
        );
    }
}

CommentModal.propTypes = {
    addComment: PropTypes.func.isRequired,
    isAuthenticated: PropTypes.string,
    comment: PropTypes.object.isRequired,
    user: PropTypes.object.isRequired,
    addFavorite: PropTypes.func.isRequired,
    deleteFavorite: PropTypes.func.isRequired,
    clearErrors: PropTypes.func.isRequired,
    error: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    isAuthenticated: state.auth.isAuthenticated,
    comment: state.comment,
    user: state.auth.user,
    error: state.error
});



export default connect(mapStateToProps, { addComment, addFavorite, deleteFavorite, clearErrors  })(CommentModal);