import React, { Component } from 'react';
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    Form,
    FormGroup,
    Label,
    Input,
    Alert,
    Tooltip
} from 'reactstrap';
import { connect } from 'react-redux';
import { addMessage } from '../actions/messageActions';
import PropTypes from 'prop-types';
import { clearErrors } from '../actions/errorActions';

class SendMessageModal extends Component {
    constructor(props) {
        super(props);
        this.state = { modal: false, title: '',message: '', receiverUsername: this.props.receiverUsername,tooltipOpen:false }
    }

    componentDidUpdate(prevProps) {
        const { error } = this.props;
        if (error !== prevProps.error) {
            if (error.id === 'MESSAGE_FAIL') {
                this.setState({ msg: error.msg.msg });
            } else {
                this.setState({ msg: null })
            }

        }
        else if (this.state.modal && prevProps.message !== this.props.message) {
            this.setState({ msg: null })
            this.toggle();
        }

    }

    toggleTooltip = () => {
        this.setState({
            tooltipOpen: !this.state.tooltipOpen
        });
    }

    toggle = () => {
        // Clear errors
        this.props.clearErrors();

        this.setState({
            modal: !this.state.modal,
            title: '',
            message: '',
            receiverUsername: this.props.receiverUsername
        });
    }

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    onSubmit = e => {
        e.preventDefault();

        const newMessage = {
            title: this.state.title,
            message: this.state.message,
            senderUsername: this.props.username,
            receiverUsername: this.state.receiverUsername

        }

        //Add message via addMesssage action
        this.props.addMessage(newMessage);


    }

    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        return (
            <div >
                {this.props.receiverUsername === 'Add a receiver' ?
                    <Button color="dark" style={{ marginBottom: '2rem' }} onClick={this.toggle}> Send Message </Button>
                    : <div><Tooltip placement="right" isOpen={this.state.tooltipOpen} target={"tooltip" + this.props.commentId} toggle={this.toggleTooltip} >Click to Message </Tooltip>
                        <h4 style={{ fontSize: "1.5vw" }} id={"tooltip" + this.props.commentId} onClick={this.toggle}> {this.props.receiverUsername} </h4>
                        </div>
                    }
                <Modal isOpen={this.state.modal} toggle={this.toggle} size='sm'>
                    <ModalHeader toggle={this.toggle}>Send your Message</ModalHeader>
                    <ModalBody>
                        {this.state.msg ? <Alert color="danger">{this.state.msg}</Alert> : null}
                        <Form onSubmit={this.onSubmit}>
                            <FormGroup>
                                <Label for="title"> Tittle </Label>
                                <Input type="text" name="title" id="title" placeholder="Add Title" onChange={this.onChange} />
                                <Label for="receiverUsername"> Receiver Username </Label>
                                <Input type="text" name="receiverUsername" id="receiverUsername" placeholder={this.state.receiverUsername} onChange={this.onChange} />
                                <Label for="message"> Message </Label>
                                <Input type="textarea" name="message" id="message" placeholder="Add Message" onChange={this.onChange} />
                                <Button color="dark" style={{ marginTop: '2rem' }} block >Send your Message</Button>
                            </FormGroup>
                        </Form>
                    </ModalBody>
                </Modal>
            </div>
        );
    }
}

SendMessageModal.propTypes = {
    addMessage: PropTypes.func.isRequired,
    isAuthenticated: PropTypes.string,
    error: PropTypes.object.isRequired,
    clearErrors: PropTypes.func.isRequired,
    message: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    isAuthenticated: state.auth.isAuthenticated,
    message: state.message,
    error: state.error
});



export default connect(mapStateToProps, { addMessage, clearErrors })(SendMessageModal);