import React, { Component } from 'react';
import { Container,  Row, Col, Button, Jumbotron } from 'reactstrap';
import { connect } from 'react-redux';
import { Link }  from 'react-router-dom';
import PropTypes from 'prop-types';
import 'bootstrap/dist/css/bootstrap.min.css';
import RegisterModal from './auth/RegisterModal';
import LoginModal from './auth/LoginModal';
import Image from 'react-bootstrap/Image';
import img from '../images/homeimage.jpg'


class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    render() {
        return(
        <Container>
                <Col style={{ float: "left", width: "50%", marginTop: '3.5rem' }}>
                    <Link to="/Places">
                        <Image src={img} fluid rounded style={{ height: "100%" }} />
                    </Link>
            </Col>
                <Col style={{ float: "left", width: "50%" }} >
                    <Jumbotron >
                        <p style={{ fontSize: "2.5vw" }}><b> Welcome to TripSpot!</b></p>
                        <p style={{ fontSize: "1.2vw" }}>
                            Find awesome places to visit all around 
                            the world. Check reviews and photos of other users
                            and also chat with them. Propose places or comment
                            existing ones. Make your own favorite list of places so you could
                            plan your next trip.
                        </p>
                        <p> 
                            {this.props.isAuthenticated === "false" ?
                                <Row>   <RegisterModal /> <p style={{ marginTop: "0.5rem" }}> or </p> <LoginModal /> <p style={{ marginTop: "0.5rem" }}> for the whole experience! </p> </Row> :
                                <Row>   <Button  href="/Favorites" color="dark" > Explore your Favorities </Button> </Row>}
                        </p>
                    </Jumbotron>
            </Col>
            </Container>

    )}
}





Home.propTypes = {

    isAuthenticated: PropTypes.string,

}

const mapStateToProps = state => ({
    isAuthenticated: state.auth.isAuthenticated,
});



export default connect(mapStateToProps, {  })(Home);