import React, { Component } from 'react';
import Map from './Map';
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    Col,
    Row
} from 'reactstrap';
import Image from 'react-bootstrap/Image';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';



class RequestModal extends Component {
    constructor(props) {
        super(props);
        this.state = { modal: false, images: [] }
    }


    toggle = () => {
        this.setState({
            modal: !this.state.modal, images: []
        });
    }

    renderImages = (reqst) => {
        const style = {
            width: "100%",
            height: " 100%",
            backgroundPosition: "50% 50%",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
        }
        var x = 0;
        return reqst.images.map((image) => {
            return (

                <Col style={{ width: "100px", height: "100px" }} key={"col" + (x++)}>
                    <Image src={image} style={style} rounded />
                </Col>
            );
        })

    }

    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        const reqst = this.props.reqst;
        return (
            <div>
                <Button color="dark" style={{ marginLeft: '1rem', marginTop: '0.3rem' }} onClick={this.toggle}> Show Details </Button>

                <Modal isOpen={this.state.modal} toggle={this.toggle} size='m'>
                    <ModalHeader toggle={this.toggle}> Details </ModalHeader>
                    <ModalBody>
                        <div>
                        {reqst.coords !== undefined ?
                            <Col>
                                <Map sz={{ height: "30vh", width: "30vw" }} draggable='false' coords={reqst.coords} />
                                </Col> : null}
                            <Row> {this.renderImages(reqst)} </Row>
                            {reqst.coords !== undefined ? null :
                                <p>{reqst.description}</p>}
                        </div>
                    </ModalBody>
                </Modal>
            </div>
        );
    }
}

RequestModal.propTypes = {
    isAuthenticated: PropTypes.string,
}

const mapStateToProps = state => ({
    isAuthenticated: state.auth.isAuthenticated,

});



export default connect(mapStateToProps, { })(RequestModal);