import React, { Component } from 'react';
import { Container, ListGroup, ListGroupItem, Alert} from 'reactstrap';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import { connect } from 'react-redux';
import { getCategories } from '../actions/categoryActions';
import PropTypes from 'prop-types';
import CategoryModal from './CategoryModal';
import Pagination from "react-js-pagination";
import 'bootstrap/dist/css/bootstrap.min.css';

class CategoriesList extends Component {
    constructor(props) {
        super(props);
        this.state = { currentPage: 1, pageCount: 1 }
    }

    componentDidMount() {
        this.props.getCategories();
    }

    componentDidUpdate(prevProps) {
        if (this.props.category !== prevProps.category) {
            const { categories } = this.props.category;
            this.setState({
                pageCount: Math.ceil(categories.length / 10.0),
                currentPage: this.state.currentPage > Math.ceil(categories.length / 10.0) ? 1 : this.state.currentPage
            })
        }
    }

    // Change Page Pagination
    handlePageChange = (pageNumber) => {
        this.setState({ currentPage: pageNumber });
    }

    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        if (this.props.isAdmin === false) return (<Alert color="danger">You have to be an admin to access this page</Alert>);
        const { categories } = this.props.category;
        const categoriesPagination = categories.length < (10 * (this.state.currentPage - 1)) + 10 ? categories.slice(10 * (this.state.currentPage - 1), categories.length  )
            : categories.slice(10 * (this.state.currentPage - 1), (10 * (this.state.currentPage - 1)) +10)
        
        return (
            <Container>
                <CategoryModal />
                <ListGroup>
                    <TransitionGroup className="category-list">
                        {categoriesPagination.map(({ _id, name }) => (
                            <CSSTransition key={_id} timeout={500} classNames="fade">
                                <ListGroupItem striped>
                                    {name}
                               </ListGroupItem>
                            </CSSTransition>
                        ))}
                    </TransitionGroup>
                </ListGroup>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop : "1rem" }} >
                <Pagination
                    itemClass="page-item"
                    linkClass="page-link"
                    hideDisabled
                    activePage={this.state.currentPage}
                    itemsCountPerPage={10}
                    totalItemsCount={categories.length}
                    pageRangeDisplayed={5}
                    onChange={this.handlePageChange}
                  />
                </div>
            </Container>
        );
    }
}

CategoriesList.propTypes = {
    getCategories: PropTypes.func.isRequired,
    category: PropTypes.object.isRequired,
    isAuthenticated: PropTypes.string,
    isAdmin: PropTypes.bool.isRequired
}

const mapStateToProps = state => ({
    category: state.category,
    isAuthenticated: state.auth.isAuthenticated,
    isAdmin: state.auth.isAdmin
});



export default connect(mapStateToProps, { getCategories })(CategoriesList);