import React, { Component } from 'react';
import { Container, ListGroup, ListGroupItem, Col, Row, Table, Button } from 'reactstrap';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import { connect } from 'react-redux';
import { getPlaces } from '../actions/placeActions';
import { getCategories } from '../actions/categoryActions';
import PropTypes from 'prop-types';
import PlaceModal from './PlaceModal';
import Image from 'react-bootstrap/Image';
import CommentsModal from './CommentsModal';
import SearchModal from './SearchModal';
import { getFavorites } from '../actions/favoriteActions';
import { getComments } from '../actions/commentActions';
import Pagination from "react-js-pagination";
import 'bootstrap/dist/css/bootstrap.min.css';



class PlacesList extends Component {
    constructor(props) {
        super(props);
        this.state = { search: false, currentPage: 1, pageCount: 1 }
    }

    componentDidMount() {
        this.props.getCategories();
        this.props.getFavorites();
        this.props.getComments();
    }
    componentDidUpdate(prevProps, prevState) {
        if (this.props.place !== prevProps.place) {
            const { places } = this.props.place;
            this.setState({
                pageCount: Math.ceil(places.length / 5.0),
                currentPage: this.state.currentPage > Math.ceil(places.length / 5.0) ? 1 : this.state.currentPage
            })
        }
        const { categories } = this.props.category;
        if (prevProps.category !== this.props.category && this.state.search === false) {
            const search = {
                name: "",
                country: "",
                city: "",
                categories: categories.map((category) => { return category.name }),
                coords: [
                    -0.481747846041145,
                    51.3233379650232
                ],
                km: Number.MAX_VALUE
            };
            this.props.getPlaces(search);
        }
     
    }

    // Change Page Pagination
    handlePageChange = (pageNumber) => {
        this.setState({ currentPage: pageNumber });
    }


    // Reset Button
    Reset = () => {
        const { categories } = this.props.category;
        const search = {
            name: "",
            country: "",
            city: "",
            categories: categories.map((category) => { return category.name }),
            coords: [
                -0.481747846041145,
                51.3233379650232
            ],
            km: Number.MAX_VALUE
        };
        this.props.getPlaces(search);
    }

   // Search Button
    Search = (search) => {
        this.setState({search: true})
        this.props.getPlaces(search);
    }
    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        const { places } = this.props.place;
        const { comments } = this.props.comment;
        const placesPagination = places.length < (5 * (this.state.currentPage - 1)) + 5 ? places.slice(5 * (this.state.currentPage - 1), places.length)
            : places.slice(5 * (this.state.currentPage - 1), (5 * (this.state.currentPage - 1)) + 5)
        return (
            <Container>
                <Row>
                    <SearchModal categories={this.props.category.categories} Search={this.Search} /> <PlaceModal /> 
                    <Button color="dark" style={{ marginLeft: '2rem', marginBottom: '2rem' }} onClick={this.Reset}> Reset search </Button>
                </Row>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }} >
                    <Pagination
                        itemClass="page-item"
                        linkClass="page-link"
                        hideDisabled
                        activePage={this.state.currentPage}
                        itemsCountPerPage={5}
                        totalItemsCount={places.length}
                        pageRangeDisplayed={5}
                        onChange={this.handlePageChange}
                    />
                </div>
                <ListGroup>
                    <TransitionGroup className="place-list">
                        {placesPagination.map((place ) => (
                            <CSSTransition   key={place._id} timeout={500} classNames='fade'>
                                <ListGroupItem key={place._id} style={{ textAlign: "center" }} >
                                    <Container>
                                    <Row >
                                        <Col sm={3}
                                            key={"col" + place.images[0]}>
                                            <Image style={{ width: "100%", height: "90%" }}
                                                src={place.images[0]} rounded />
                                        </Col>
                                        <Col sm={9} >
                                                <Table striped bordered hover variant="dark"
                                                    style={{ width: "100%", height: "90%", overflow:"auto" }} repsonsive="sm">
                                                <thead>
                                                    <tr >
                                                  <th style={{ width: "20%", fontSize:"3vh" }}>Name</th>
                                                            <td style={{ fontSize: "2.5vh" }}>{place.name}</td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                            <th style={{ width: "20%", fontSize: "3vh" }}>Category</th>
                                                            <td style={{ fontSize: "2.5vh" }}>{place.category}</td>
                                                    </tr>
                                                    <tr >
                                                            <th style={{ width: "20%", fontSize: "3vh" }}>Country</th>
                                                            <td style={{ fontSize: "2.5vh" }}>{place.country}</td>
                                                    </tr>
                                                    <tr >
                                                            <th style={{ width: "20%", fontSize: "3vh" }}>City</th>
                                                            <td style={{ fontSize: "2.5vh" }}>{place.city}</td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </Col>
                                        </Row>
                                        <CommentsModal place={place} comments={comments.filter((comment) =>place._id === comment.placeId)} favorites= { this.props.favorite.favorites.map((favorite) => favorite.placeId) } />
                                        </Container>
                                </ListGroupItem>
                            </CSSTransition>
                        ))}
                    </TransitionGroup>
                </ListGroup>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: "1rem" }} >
                    <Pagination
                        itemClass="page-item"
                        linkClass="page-link"
                        hideDisabled
                        activePage={this.state.currentPage}
                        itemsCountPerPage={5}
                        totalItemsCount={places.length}
                        pageRangeDisplayed={5}
                        onChange={this.handlePageChange}
                    />
                </div>
            </Container>
        );
    }
}
PlacesList.propTypes = {
    getPlaces: PropTypes.func.isRequired,
    getCategories: PropTypes.func.isRequired,
    place: PropTypes.object.isRequired,
    getFavorites: PropTypes.func.isRequired,
    isAuthenticated: PropTypes.string,
    category: PropTypes.object.isRequired,
    favorite: PropTypes.object.isRequired,
    getComments: PropTypes.func.isRequired,
    comment: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    place: state.place,
    category: state.category,
    favorite: state.favorite,
    isAuthenticated: state.auth.isAuthenticated,
    comment: state.comment
});



export default connect(mapStateToProps, { getPlaces, getCategories, getFavorites, getComments  })(PlacesList);