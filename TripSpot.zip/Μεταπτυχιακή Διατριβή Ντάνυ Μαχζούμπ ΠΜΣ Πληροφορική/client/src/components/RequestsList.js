import React, { Component } from 'react';
import { Container, Button, Alert,Table,Row } from 'reactstrap';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { getAdminPlaces, acceptPlace, deletePlace,getMyPlaces } from '../actions/placeActions';
import { getAdminComments, acceptComment, deleteComment,getMyComments } from '../actions/commentActions';
import Tabs from 'react-bootstrap/Tabs'
import Tab from 'react-bootstrap/Tab'
import Stars from './Stars';
import RequestModal from './RequestModal';
import Pagination from "react-js-pagination";
import 'bootstrap/dist/css/bootstrap.min.css';


class RequestsList extends Component {
    constructor(props) {
        super(props);
        this.state = { key: 'Places',currentPage: 1, pageCount: 1}
    }



    componentDidMount() {
        if (this.props.admin === "true") {
            this.props.getAdminComments();
            this.props.getAdminPlaces();
        }
        else {
            this.props.getMyComments();
            this.props.getMyPlaces();
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.place !== prevProps.place || this.props.comment !== prevProps.comment) {
            const { comments } = this.props.comment;
            const { places } = this.props.place;
            if (this.state.key === "Places") {
                this.setState({
                    pageCount: Math.ceil(places.length / 5.0),
                    currentPage: this.state.currentPage > Math.ceil(places.length / 5.0) ? 1 : this.state.currentPage

                })
            }
            else {
                this.setState({
                    pageCount: Math.ceil(comments.length / 5.0),
                    currentPage: this.state.currentPage > Math.ceil(comments.length / 5.0) ? 1 : this.state.currentPage

                })
            }
        }
    }

    onSelect = (key) => {
        this.setState({ key: key });
        const { comments } = this.props.comment;
        const { places } = this.props.place;
        if (key === "Places") {
            this.setState({
                pageCount: Math.ceil(places.length / 5.0),
                currentPage: this.state.currentPage > Math.ceil(places.length / 5.0) ? 1 : this.state.currentPage

            })
        }
        else {
            this.setState({
                pageCount: Math.ceil(comments.length / 5.0),
                currentPage: this.state.currentPage > Math.ceil(comments.length / 5.0) ? 1 : this.state.currentPage

            })
        }
    }

    // Change Page Pagination
    handlePageChange = (pageNumber) => {
        this.setState({ currentPage: pageNumber });
    }


    accept = (id) => {
        if (this.state.key === 'Places') {
            this.props.acceptPlace(id);
        }
        else {
            this.props.acceptComment(id);
        }
    }

    delete = (id) => {
        if (this.state.key === 'Places') {
            this.props.deletePlace(id);
        }
        else {
            this.props.deleteComment(id);
        }

    }

    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        if (this.props.isAuthenticated === "false" && this.props.admin === "false") return (<Alert color="danger">You have to  login to access this page</Alert>);
        if (this.props.isAdmin === false && this.props.admin === "true") return (<Alert color="danger">You have to be an admin to access this page</Alert>);
        const { places } = this.props.place;
        const { comments } = this.props.comment;
        const placesPagination = places.length < (5 * (this.state.currentPage - 1)) + 5 ? places.slice(5 * (this.state.currentPage - 1), places.length)
            : places.slice(5 * (this.state.currentPage - 1), (5 * (this.state.currentPage - 1)) + 5)
        const commentsPagination = comments.length < (5 * (this.state.currentPage - 1)) + 5 ? comments.slice(5 * (this.state.currentPage - 1), comments.length)
            : comments.slice(5 * (this.state.currentPage - 1), (5 * (this.state.currentPage - 1)) + 5)
        return (
            <Container>
                <Tabs  activeKey={this.state.key} onSelect={this.onSelect}>
                    <Tab eventKey="Places" title="Places">
                                <Table striped bordered hover variant="dark"
                            style={{ overflow: "auto" }} repsonsive="sm">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Category</th>
                                            <th>Country</th>
                                            <th>City</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                            
                                {placesPagination.map((place) => (
                                   
                                            <tr>
                                            <td>{place.name}</td>
                                            <td>{place.category}</td>
                                            <td>{place.country}</td>
                                            <td>{place.city}</td>
                                        <td>
                                            <Row>
                                                    <RequestModal reqst={place} /> 
                                                    {this.props.admin === "true" ? <div>
                                                        <Button color="dark" style={{ marginLeft: '1rem', marginTop: '0.3rem' }}onClick={() =>this.accept(place._id)}> Accept </Button>
                                                        <Button color="dark" style={{ marginLeft: '1rem', marginTop: '0.3rem' }} onClick={() => this.delete(place._id)}> Delete </Button> </div>
                                                    : place.accepted ? <h4 style={{ fontSize: "1vw", color: "green", marginLeft: '1rem', marginTop: '0.3rem' }} >ACCEPTED</h4> : <h4 style={{ fontSize: "1vw", color: "orange", marginLeft: '1rem', marginTop: '0.3rem' }}>PENDING</h4>}
                                                </Row>
                                            </td>
                                            </tr>
                                   
                                ))}
                          
                            </tbody>
                        </Table>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: "1rem" }} >
                            <Pagination
                                itemClass="page-item"
                                linkClass="page-link"
                                hideDisabled
                                activePage={this.state.currentPage}
                                itemsCountPerPage={5}
                                totalItemsCount={places.length}
                                pageRangeDisplayed={5}
                                onChange={this.handlePageChange}
                            />
                        </div>
                    </Tab>
                    <Tab eventKey="Comments" title="Comments">
                        <Table striped bordered hover variant="dark"
                            style={{ overflow: "auto" }} repsonsive="sm">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Place Name</th>
                                    <th>Stars</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {commentsPagination.map((comment) => (
                                    <tr>
                                                <td>{comment.title}</td>
                                                <td>{comment.placeName}</td>                                              
                                                <td><Stars id="stars" selectable={false} stars={comment.stars} /></td>
                                                <td>
                                        <Row>
                                                <RequestModal reqst={comment} />
                                                {this.props.admin === "true" ? <div>
                                                    <Button color="dark" style={{ marginLeft: '1rem', marginTop: '0.3rem' }} onClick={() => this.accept(comment._id)}> Accept </Button>
                                                    <Button color="dark" style={{ marginLeft: '1rem', marginTop: '0.3rem' }} onClick={() => this.delete(comment._id)}> Delete </Button> </div>
                                                    : comment.accepted ? <h4 style={{ color: "green", marginLeft: '1rem', marginTop: '0.3rem', fontSize: "1vw" }} >ACCEPTED</h4> : <h4 style={{ fontSize: "1vw",color: "orange", marginLeft: '1rem', marginTop: '0.3rem' }}>PENDING</h4>}
                                        </Row>
                                            </td>
                                            </tr>
                                   
                                ))}
                          
                            </tbody>
                        </Table>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }} >
                            <Pagination
                                itemClass="page-item"
                                linkClass="page-link"
                                hideDisabled
                                activePage={this.state.currentPage}
                                itemsCountPerPage={5}
                                totalItemsCount={comments.length}
                                pageRangeDisplayed={5}
                                onChange={this.handlePageChange}
                            />
                        </div>
                    </Tab>
                </Tabs>
            </Container>
        );
    }
}

RequestsList.propTypes = {
    getAdminPlaces: PropTypes.func.isRequired,
    acceptPlace: PropTypes.func.isRequired,
    deletePlace: PropTypes.func.isRequired,
    getMyPlaces: PropTypes.func.isRequired,
    place: PropTypes.object.isRequired,
    getAdminComments: PropTypes.func.isRequired,
    acceptComment: PropTypes.func.isRequired,
    deleteComment: PropTypes.func.isRequired,
    getMyComments: PropTypes.func.isRequired,
    comment: PropTypes.object.isRequired,
    isAuthenticated: PropTypes.string,
    isAdmin: PropTypes.bool.isRequired,
}

const mapStateToProps = state => ({
    place: state.place,
    comment: state.comment,
    isAuthenticated: state.auth.isAuthenticated,
    isAdmin: state.auth.isAdmin,
});



export default connect(mapStateToProps, { getAdminPlaces, getAdminComments, acceptPlace, deletePlace, acceptComment, deleteComment, getMyPlaces, getMyComments })(RequestsList);