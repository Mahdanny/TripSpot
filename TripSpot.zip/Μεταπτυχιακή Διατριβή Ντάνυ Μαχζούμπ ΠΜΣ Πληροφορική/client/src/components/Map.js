import React, { Component } from 'react';
import ReactMapboxGl, { Layer, Feature } from "react-mapbox-gl";
import style from "./mapStyle/style.json";
const MapGl = ReactMapboxGl({
    accessToken: "pk.eyJ1IjoibWFoZGFubnkiLCJhIjoiY2tqMHRlZ3AxMm53dTJ1bW14OHQ1azdleCJ9.y4qeBLsrRQyCknTu7oFAjQ",
    attributionControl: false
});            
export default class Map extends Component {
    constructor(props) {
      super(props);
      this.state={
        coords:this.props.coords
      };
    }
    componentDidUpdate(prevProps) {
        if (this.props.coords !== prevProps.coords) {
            this.setState({
                coords: this.props.coords
            })
        }
    }
     onDragEnd=(e)=> {
         this.props.onChangeCoords(e.lngLat)
   
    }
    render(){
        if(String(this.state.coords[0])==="undefined") return ((null));
        return (
            <div>
            <MapGl containerStyle={this.props.sz}
                style={style} center={[this.state.coords[0], this.state.coords[1]]}>
                <Layer type="symbol" id="marker" layout={{ 'icon-image': 'marker-15', 'icon-size': 3}}>
                    {this.props.draggable === 'true' ? <Feature onDragEnd={this.onDragEnd} draggable="true" coordinates={[this.state.coords[0], this.state.coords[1]]} />
                        : <Feature coordinates={[this.state.coords[0], this.state.coords[1]]} />}
                    
                </Layer>
                </MapGl>
                <p style={{ fontSize: "1vw" }}>{"Lon: " + this.state.coords[0] + ', Lat:' + this.state.coords[1]} </p>
            </div>
        );
    } 
}  
            