import React, { Component } from 'react';
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    Form,
    FormGroup,
    Label,
    Input,
    Alert
} from 'reactstrap';
import { connect } from 'react-redux';
import { addCategory } from '../actions/categoryActions';
import PropTypes from 'prop-types';
import { clearErrors } from '../actions/errorActions';

class CategoryModal extends Component {
    constructor(props) {
        super(props);
        this.state = {modal:false,name:''}
    }

    componentDidUpdate(prevProps) {
        const { error } = this.props;
        if (error !== prevProps.error) {
            if (error.id === 'CATEGORY_FAIL') {
                this.setState({ msg: error.msg.msg });
            } else  {
                this.setState({ msg: null })
            }
            
        }
        else if (this.state.modal && prevProps.category!==this.props.category) {
            this.setState({ msg: null })
            this.toggle();
        }

    }

    toggle = () => {
        // Clear errors
        this.props.clearErrors();

        this.setState({
            modal: !this.state.modal,
            name: ''
        });
    }

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    onSubmit = e => {
        e.preventDefault();

        const newCategory = {
            name: this.state.name
        }

        //Add category via addCategory action
        this.props.addCategory(newCategory);

  
    }

    render() {
        if (this.props.isAuthenticated === "undefined") return ((null));
        return (
            <div>
                    <Button color="dark" style={{ marginBottom: '2rem' }} onClick={this.toggle}> Add Category </Button>
                <Modal isOpen={this.state.modal} toggle={this.toggle}>
                    <ModalHeader toggle={this.toggle}> Add to Categories List </ModalHeader>
                    <ModalBody>
                        {this.state.msg ? <Alert color="danger">{this.state.msg}</Alert> : null}
                        <Form onSubmit={this.onSubmit}>
                            <FormGroup>
                                <Label for="name"> Name </Label>
                                <Input type="text" name="name" id="name" placeholder="Add Name" onChange={this.onChange} />
                                <Button color="dark" style={{marginTop: '2rem'}} block >Add Category</Button>
                            </FormGroup>
                        </Form>
                    </ModalBody>
                </Modal>
            </div>
            );
    }
}

CategoryModal.propTypes = {
    addCategory: PropTypes.func.isRequired,
    isAuthenticated: PropTypes.string,
    error: PropTypes.object.isRequired,
    clearErrors: PropTypes.func.isRequired,
    category: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    isAuthenticated: state.auth.isAuthenticated,
    category: state.category,
    error: state.error
});



    export default connect(mapStateToProps, { addCategory, clearErrors })(CategoryModal);