import { GET_PLACES, ADD_PLACE, DELETE_PLACE, PLACES_LOADING, ACCEPT_PLACE, PLACES_FAIL, PLACE_FAIL} from './types';
import axios from 'axios';
import { tokenConfig } from './authActions';
import { returnErrors } from './errorActions';

export const getPlaces = (search) => dispatch => {
    dispatch(setPlacesLoading());
    axios
        .post('/api/places/search', search)
        .then(res =>
            dispatch({
                type: GET_PLACES,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'PLACES_FAIL'));
            dispatch({
                type: PLACES_FAIL
            })
        });
};


export const addPlace = (place) => (dispatch, getState) => {

    if (!place.name || !place.country || !place.city || !place.images[0]) {
        dispatch(returnErrors({ msg: "Please enter all fields" }, 400, 'PLACE_FAIL'));
        dispatch({
            type: PLACE_FAIL
        })
        return;
    }


    const form_data = new FormData();
    place.images.forEach((image) => {
        form_data.append('images', image);
    });
    form_data.append('name', place.name);
    form_data.append('category', place.category);
    form_data.append('country', place.country);
    form_data.append('city', place.city);
    form_data.append('coords', place.coords[0]);
    form_data.append('coords', place.coords[1]);
    axios
        .post('/api/places/create', form_data, tokenConfig(getState))
        .then(res =>
            dispatch({
                type: ADD_PLACE,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'PLACE_FAIL'));
            dispatch({
                type: PLACE_FAIL
            })
        });
};

export const deletePlace = (id) => (dispatch, getState) => {
    axios.delete(`/api/places/delete/${id}`, tokenConfig(getState)).then(res =>
        dispatch({
            type: DELETE_PLACE,
            payload: id
        }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'PLACE_FAIL'));
            dispatch({
                type: PLACE_FAIL
            })
        });
};

export const getMyPlaces = () => (dispatch,getState) => {
    dispatch(setPlacesLoading());
    axios
        .get('/api/places/myrequests', tokenConfig(getState))
        .then(res =>
            dispatch({
                type: GET_PLACES,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'PLACES_FAIL'));
            dispatch({
                type: PLACES_FAIL
            })
        });
};


export const getAdminPlaces = () => (dispatch, getState) => {
    dispatch(setPlacesLoading());
    axios
        .get('/api/places/admin', tokenConfig(getState))
        .then(res =>
            dispatch({
                type: GET_PLACES,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'PLACES_FAIL'));
            dispatch({
                type: PLACES_FAIL
            })
        });
};

export const acceptPlace = (id) => (dispatch, getState) => {
    axios
        .post(`/api/places/accept/${id}`, {},tokenConfig(getState))
        .then(res =>
            dispatch({
                type: ACCEPT_PLACE,
                payload: id
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'PLACE_FAIL'));
            dispatch({
                type: PLACE_FAIL
            })
        });
};

export const getFavoritesDetails = (ids) => (dispatch, getState) => {
    dispatch(setPlacesLoading());
    axios
        .post('/api/places/favorites', ids, tokenConfig(getState))
        .then(res =>
            dispatch({
                type: GET_PLACES,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'PLACES_FAIL'));
            dispatch({
                type: PLACES_FAIL
            })
        });
};

export const setPlacesLoading = () => {
    return {
        type: PLACES_LOADING
    }
}