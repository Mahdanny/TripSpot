import { GET_FAVORITES, ADD_FAVORITE, FAVORITES_LOADING,  FAVORITES_FAIL, DELETE_FAVORITE } from './types';
import axios from 'axios';
import { tokenConfig } from './authActions';
import { returnErrors } from './errorActions';

export const getFavorites = () => (dispatch, getState) => {
    dispatch(setFavoritesLoading());
    axios
        .get('/api/favorites', tokenConfig(getState))
        .then(res =>
            dispatch({
                type: GET_FAVORITES,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'FAVORITES_FAIL'));
            dispatch({
                type: FAVORITES_FAIL
            })
        });
};


export const addFavorite = (favorite) => (dispatch, getState) => {
    axios
        .post('/api/favorites', favorite, tokenConfig(getState))
        .then(res =>
            dispatch({
                type: ADD_FAVORITE,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'FAVORITE_FAIL'));
            dispatch({
                type: FAVORITES_FAIL
            })
        });
};

export const deleteFavorite = (id) => (dispatch, getState) => {
    axios.delete(`/api/favorites/${id}`, tokenConfig(getState)).then(res => 
        dispatch({
        type: DELETE_FAVORITE,
        payload: res.data.id
    }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'FAVORITE_FAIL'));
            dispatch({
                type: FAVORITES_FAIL
            })
        });
};


export const setFavoritesLoading = () => {
    return {
        type: FAVORITES_LOADING
    }
}