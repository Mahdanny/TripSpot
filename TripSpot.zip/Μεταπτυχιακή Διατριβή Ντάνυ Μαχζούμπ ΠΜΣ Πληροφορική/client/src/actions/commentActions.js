import { GET_COMMENTS, ADD_COMMENT, DELETE_COMMENT, ACCEPT_COMMENT, COMMENTS_LOADING, COMMENTS_FAIL, COMMENT_FAIL} from './types';
import axios from 'axios';
import { tokenConfig } from './authActions';
import { returnErrors } from './errorActions';

export const getComments = () => dispatch => {
    dispatch(setCommentsLoading());
    axios
        .get("/api/comments")
        .then(res =>
            dispatch({
                type: GET_COMMENTS,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'COMMENTS_FAIL'));
            dispatch({
                type: COMMENTS_FAIL
            })
        });
};


export const addComment = (comment) => (dispatch, getState) => {

    if (!comment.title || !comment.description || comment.images.length === 0 ) {
        dispatch(returnErrors({ msg: "Please enter all fields" }, 400, 'COMMENT_FAIL'));
        dispatch({
            type: COMMENT_FAIL
        })
        return;
    }

    const form_data = new FormData();
    comment.images.forEach((image) => {
        form_data.append('images', image);
    });
    form_data.append('title', comment.title);
    form_data.append('description', comment.description);
    form_data.append('stars', comment.stars);
    form_data.append('creatorUsername', comment.creatorUsername);
    form_data.append('placeId', comment.placeId);
    form_data.append('placeName', comment.placeName);
    axios
        .post('/api/comments/create', form_data, tokenConfig(getState))
        .then(res =>
            dispatch({
                type: ADD_COMMENT,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'COMMENT_FAIL'));
            dispatch({
                type: COMMENT_FAIL
            })
        });
};

export const deleteComment = (id) => (dispatch, getState) => {
    axios.delete(`/api/comments/delete/${id}`, tokenConfig(getState)).then(res =>
        dispatch({
            type: DELETE_COMMENT,
            payload: id
        }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'COMMENT_FAIL'));
            dispatch({
                type: COMMENT_FAIL
            })
        });
};

export const getMyComments = () => (dispatch, getState) => {
    dispatch(setCommentsLoading());
    axios
        .get('/api/comments/myrequests', tokenConfig(getState))
        .then(res =>
            dispatch({
                type: GET_COMMENTS,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'COMMENTS_FAIL'));
            dispatch({
                type: COMMENT_FAIL
            })
        });
};


export const getAdminComments = () => (dispatch, getState) => {
    dispatch(setCommentsLoading());
    axios
        .get('/api/comments/admin', tokenConfig(getState))
        .then(res =>
            dispatch({
                type: GET_COMMENTS,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'COMMENTS_FAIL'));
            dispatch({
                type: COMMENT_FAIL
            })
        });
};

export const acceptComment = (id) => (dispatch, getState) => {
    axios
        .post(`/api/comments/accept/${id}`, {}, tokenConfig(getState))
        .then(res =>
            dispatch({
                type: ACCEPT_COMMENT,
                payload: id
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'COMMENT_FAIL'));
            dispatch({
                type: COMMENT_FAIL
            })
        });
};

export const setCommentsLoading = () => {
    return {
        type: COMMENTS_LOADING
    }
}