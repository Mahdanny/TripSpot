import { GET_MESSAGES, ADD_MESSAGE, MESSAGES_LOADING, MESSAGE_FAIL, MESSAGES_FAIL  } from './types';
import axios from 'axios';
import { tokenConfig } from './authActions';
import { returnErrors } from './errorActions';

export const getMessages = () => (dispatch, getState) => {
    dispatch(setMessagesLoading());
    axios
        .get('/api/messages', tokenConfig(getState))
        .then(res =>
            dispatch({
                type: GET_MESSAGES,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'MESSAGES_FAIL'));
            dispatch({
                type: MESSAGES_FAIL
            })
        });
};


export const addMessage = (message) => (dispatch, getState) => {

    if (!message.title || !message.message || !message.receiverUsername) {
        dispatch(returnErrors({ msg: "Please enter all fields" }, 400, 'MESSAGE_FAIL'));
        dispatch({
            type: MESSAGE_FAIL
        })
        return;
    }
    axios
        .post('/api/messages', message, tokenConfig(getState))
        .then(res =>
            dispatch({
                type: ADD_MESSAGE,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'MESSAGE_FAIL'));
            dispatch({
                type: MESSAGE_FAIL
            })
        });
};

export const setMessagesLoading = () => {
    return {
        type: MESSAGES_LOADING
    }
}