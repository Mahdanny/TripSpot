import { GET_CATEGORIES, ADD_CATEGORY, CATEGORIES_LOADING, CATEGORY_FAIL, CATEGORIES_FAIL } from './types';
import axios from 'axios';
import { tokenConfig } from './authActions';
import { returnErrors } from './errorActions';

export const getCategories = () => dispatch => {
    dispatch(setCategoriesLoading());
    axios
        .get('/api/categories')
        .then(res =>
            dispatch({
                type: GET_CATEGORIES,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'CATEGORIES_FAIL'));
            dispatch({
                type: CATEGORIES_FAIL
            })
        });
};


export const addCategory = (category) => (dispatch, getState) => {

    if (!category.name) {
        dispatch(returnErrors({ msg: "Please enter category's name" }, 400, 'CATEGORY_FAIL'));
        dispatch({
            type: CATEGORY_FAIL
        })
        return;
    }

    axios
        .post('/api/categories', category, tokenConfig(getState))
        .then(res =>
            dispatch({
                type: ADD_CATEGORY,
                payload: res.data
            }))
        .catch(err => {
            dispatch(returnErrors(err.response.data, err.response.status, 'CATEGORY_FAIL'));
            dispatch({
                type: CATEGORY_FAIL
            })
        });
};

export const setCategoriesLoading = () => {
    return{
        type: CATEGORIES_LOADING
    }
}