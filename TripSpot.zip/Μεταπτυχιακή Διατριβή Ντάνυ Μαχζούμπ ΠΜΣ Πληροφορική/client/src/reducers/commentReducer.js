import { GET_COMMENTS, ADD_COMMENT, COMMENTS_LOADING,ACCEPT_COMMENT, DELETE_COMMENT, COMMENTS_FAIL, COMMENT_FAIL } from '../actions/types';

const initialState = {
    comments: [],
    loading: false
}

export default function (state = initialState, action) {
    switch (action.type) {
        case GET_COMMENTS:
            return {
                ...state,
                comments: action.payload,
                loading: false
            }
        case ADD_COMMENT:
            return {
                ...state
            }
        case COMMENTS_LOADING:
            return {
                ...state,
                loading: true
            }
        case DELETE_COMMENT:
        case ACCEPT_COMMENT:
            return {
                ...state,
                comments: state.comments.filter(comment => comment._id !== action.payload)
            }
        case COMMENTS_FAIL:
            return {
                ...state,
                comments: [],
                loading: false
            }
        case COMMENT_FAIL:
        default:
            return state;
    }
}