import { combineReducers } from 'redux';
import categoryReducer from './categoryReducer';
import commentReducer from './commentReducer';
import placeReducer from './placeReducer';
import messageReducer from './messageReducer';
import errorReducer from './errorReducer';
import authReducer from './authReducer';
import favoriteReducer from './favoriteReducer';


export default combineReducers({
    category: categoryReducer,
    place: placeReducer,
    comment: commentReducer,
    message: messageReducer,
    favorite: favoriteReducer,
    error: errorReducer,
    auth: authReducer
})