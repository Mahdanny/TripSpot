
import { GET_PLACES, ADD_PLACE, PLACES_LOADING, DELETE_PLACE, ACCEPT_PLACE, PLACES_FAIL, PLACE_FAIL } from '../actions/types';

const initialState = {
    places: [],
    loading: false
}

export default function (state = initialState, action) {
    switch (action.type) {
        case GET_PLACES:
            return {
                ...state,
                places: action.payload,
                loading: false
            }
        case ADD_PLACE:
            return {
                ...state
            }
        case PLACES_LOADING:
            return {
                ...state,
                loading: true
            }
        case DELETE_PLACE:
        case ACCEPT_PLACE:
            return {
                ...state,
                places: state.places.filter(place => place._id !== action.payload)
            }
        case PLACES_FAIL:
            return {
                ...state,
                places: [],
                loading: false
            }
        case PLACE_FAIL:
        default:
            return state;
    }
}