import { GET_CATEGORIES, ADD_CATEGORY, CATEGORIES_LOADING, CATEGORY_FAIL, CATEGORIES_FAIL } from '../actions/types';

const initialState = {
    categories: [],
    loading: false
}

export default function(state = initialState, action) {
    switch (action.type) {
        case GET_CATEGORIES:
            return {
                ...state,
                categories: action.payload,
                loading: false
            }
        case ADD_CATEGORY:
            return {
                ...state,
                categories: [action.payload, ...state.categories]
            }
        case CATEGORIES_LOADING:
            return {
                ...state,
                loading:true
            }
        case CATEGORIES_FAIL:
            return {
                ...state,
                categories: [],
                loading: false
            }
        case CATEGORY_FAIL:
        default:
            return state;
    }
}