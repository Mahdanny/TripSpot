import { GET_MESSAGES, ADD_MESSAGE, MESSAGES_LOADING, MESSAGE_FAIL, MESSAGES_FAIL } from '../actions/types';

const initialState = {
    messages: [],
    loading: false
}

export default function (state = initialState, action) {
    switch (action.type) {
        case GET_MESSAGES:
            return {
                ...state,
                messages: action.payload,
                loading: false
            }
        case ADD_MESSAGE:
            return {
                ...state,
                messages: [action.payload, ...state.messages]
            }
        case MESSAGES_LOADING:
            return {
                ...state,
                loading: true
            }
        case MESSAGES_FAIL:
            return {
                ...state,
                messages: [],
                loading: false
            }
        case MESSAGE_FAIL:
        default:
            return state;
    }
}