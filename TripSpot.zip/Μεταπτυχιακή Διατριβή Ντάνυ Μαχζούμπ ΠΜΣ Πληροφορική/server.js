const express = require('express')
const mongoose = require('mongoose')
const path = require('path');
const app = express();
const config = require('config');
const rankingsTimer = require('./rankingsUpdate');

// Bodyparser Middleware
app.use(express.json());

// DB config
const db = config.get('mongoURI');

//Connect to Mongo
mongoose
    .connect(db, {
        userNewUrlParser: true,
        useCreateIndex: true
    })
    .then(() => console.log('MongoDB Connected...'))
    .catch(err => console.log(err));

// Use Routes
app.use('/uploads', express.static('uploads'));
app.use('/api/users', users = require('./routes/api/users'));
app.use('/api/auth', auth = require('./routes/api/auth'));
app.use('/api/categories', categories = require('./routes/api/categories'));
app.use('/api/places', places = require('./routes/api/places'));
app.use('/api/comments', comments = require('./routes/api/comments'));
app.use('/api/messages', messages = require('./routes/api/messages'));
app.use('/api/favorites', favorites = require('./routes/api/favorites'));

// Serve static assets if in production
if (process.env.NODE_ENV === 'production') {
    // Set static folder
    app.use(express.static('client/build'));

    app.get('*', (req, res) => {
        res.sendFile(path.resolve(__dirname, 'client', 'build', 'index.html'));
    })
}

// timer for ranking
setInterval(rankingsTimer, 1000);

const port = process.env.PORT || 5000;

app.listen(port, () => console.log(`Server started on port ${port}`));