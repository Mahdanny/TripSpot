const express = require('express');
const router = express.Router();
const auth = require('../../middleware/auth');

// Favorite Model
const Favorite = require('../../models/Favorite');
const Place = require('../../models/Place');

// @route GET api/favorites
// @desc GET user's Favorites
// @access Private
router.get('/',auth, (req, res) => {
    Favorite.find({ userId: req.user.id })
        .select('-userId')
        .sort({ date: -1 })
        .then(favorites => res.json(favorites));
});

// @route POST api/favorites
// @desc Create a favorite
// @access Private
router.post('/', auth, (req, res) => {
    Place.findOne({ _id: req.body.placeId })
        .then(place => {
            if (!place) return res.status(400).json({ msg: 'Wrong place ID' })

            const newFavorite = new Favorite({
                placeId: req.body.placeId,
                userId: req.user.id
            });

            newFavorite.save().then(favorite => res.json(favorite));
        })
});

// @route DELETE api/favorite/:id
// @desc DELETE a user's favprote
// @access Private
router.delete('/:id', auth, (req, res) => {
    Place.findOne({ _id: req.params.id })
        .then(place => {
            if (!place) return res.status(400).json({ msg: 'Wrong place ID' })
            Favorite.findOne({ $and: [{ placeId: req.params.id }, { userId: req.user.id }] })
                .then(favorite => favorite.remove().then(() => res.json({ id: favorite._id })))
                .catch(err => res.status(404).json({ success: false }))
        })
});




module.exports = router;