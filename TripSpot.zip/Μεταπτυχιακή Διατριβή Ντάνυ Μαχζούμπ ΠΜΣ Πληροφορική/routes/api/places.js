const express = require('express');
const router = express.Router();
const auth = require('../../middleware/auth');
const multer = require('multer');
const fs = require('fs');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads/');
    },
    filename: function (req, file, cb) {
        cb(null,  Date.now() + "_" + file.originalname);
    }
});
const fileFilter = (req, file, cb) => {
    if (file.mimetype === "image/x-png" || file.mimetype === "image/png" ||
        file.mimetype === "image/jpg" || file.mimetype === "image/jpeg")
        cb(null, true);
    else cb(new Error("Only image files are allowed!"), false);
}
const upload = multer({
    storage: storage,
    limits: {
        fileSize: 1024 * 1024,
        files: 1
    },
    fileFilter: fileFilter
});
// Place Model
const Place = require('../../models/Place');

// @route POST api/places/search
// @desc Search places
// @access Public
router.post('/search', (req, res) => {

    if (req.body.categories.length === 0 || req.body.coords.length !== 2 || !req.body.coords[0] || !req.body.coords[1] || req.body.km === 0)
        return res.status(400).json({ msg: 'Please enter all fields' });

    const queryLocation = {
        coords: {
            $geoWithin: {
                $centerSphere: [[req.body.coords[0], req.body.coords[1]],
                req.body.km / 0.621371192 / 3963.2]
            }
        }
    };
    const queryCategory = { category: { $in: req.body.categories } };
    const queryName = { name: new RegExp(req.body.name, "i") };

    const queryCountry = { country: new RegExp(req.body.country, "i") };
    const queryCity = { city: new RegExp(req.body.city, "i") };

    const query = Object.assign(queryCountry, queryLocation, queryCity, queryCategory, queryName, { accepted: true });
    Place.find(query)
        .sort({ ranking: -1 })
        .then(places => res.json(places));
});

// @route post api/places/favorites
// @desc User's favorite places details
// @access Private
router.post('/favorites', auth, (req, res) => {
    Place.find({ _id: { $in: req.body.ids } })
        .sort({ date: -1 })
        .then(places => res.json(places));
});


// @route GET api/places/myrequests
// @desc User's pending or accepted places
// @access Private
router.get('/myrequests', auth,  (req, res) => {
    Place.find({   creatorId: req.user.id })
        .sort({ accepted: 1 })
        .then(places => res.json(places));
});



// @route GET api/places/admin
// @desc pending places
// @access Private
router.get('/admin', auth, (req, res) => {
    if (!req.user.admin) return res.status(400).json({ msg: "You are not an admin,you do not have access!" })
    Place.find( { accepted: false } )
        .sort({ date: 1 })
        .then(places => res.json(places));
});


// @route POST api/places/accept/:id
// @desc ACCEPT a place
// @access Private
router.post('/accept/:id', auth, (req, res) => {
    if (!req.user.admin) return res.status(400).json({ msg: "You are not an admin,you do not have access!" })
    Place.findById(req.params.id)
        .then(place => {
            if (!place) return res.status(400).json({ msg: 'Wrong place ID' })
            place.accepted = true; place.save().then(() => res.json({ success: true }))
        })
        .catch(err => res.status(404).json({ success: false }))
});

// @route DELETE api/places/delete/:id
// @desc DELETE a place
// @access Private
router.delete('/delete/:id', auth, (req, res) => {
    if (!req.user.admin) return res.status(400).json({ msg: "You are not an admin,you do not have access!" })
    Place.findById(req.params.id)
        .then(place => {
            if (!place) return res.status(400).json({ msg: 'Wrong place ID' })
            place.remove().then(() => {
                imgs = place.images;
                imgs.forEach((img) => {
                    const index = img.search("uploads");
                    var del = img.substring(index);
                    fs.unlink(del, (err) => {
                        if (err) return res.status(400).json('Error:' + err)
                    });
                });
                res.json({ success: true })
            })
        })
        .catch(err => res.status(404).json({ success: false }))
});


// @route POST api/places/create
// @desc Create a place
// @access Private
router.post('/create', auth, upload.array('images'), (req, res) => {
    const name = req.body.name;
    const name1 = new RegExp(["^", name, "$"].join(""), "i");
    const images = req.files.map((file) => {
        return "http://localhost:5000/uploads/" +
            file.filename;
    });
    if (!name || !req.body.category || images.length === 0 || !req.body.country || !req.body.city || req.body.coords.length !== 2 || !req.body.coords[0] || !req.body.coords[1] )
        return res.status(400).json({ msg: 'Please enter all fields' });

    //Check for existing place
    Place.findOne({ name: name1 })
        .then(place => {
            if (place) return res.status(400).json({ msg: 'Place already exists' })
            const newPlace = new Place({
                name: req.body.name,
                category: req.body.category,
                images: images,
                country: req.body.country,
                city: req.body.city,
                creatorId: req.user.id,
                coords: req.body.coords
            })

            newPlace.save().then(place => res.json(place));
        })
});


// @route GET api/places/:id
// @desc Place data
// @access Public
router.get('/:id', (req, res) => {
    Place.findById(req.params.id)
        .sort({ date: -1 })
        .then(place => res.json(place));
})

module.exports = router;