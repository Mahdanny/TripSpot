const express = require('express');
const router = express.Router();
const auth = require('../../middleware/auth');
const multer = require('multer');
const fs = require('fs');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + "_" + file.originalname);
    }
});
const fileFilter = (req, file, cb) => {
    if (file.mimetype === "image/x-png" || file.mimetype === "image/png" ||
        file.mimetype === "image/jpg" || file.mimetype === "image/jpeg")
        cb(null, true);
    else cb(new Error("Only image files are allowed!"), false);
}
const upload = multer({
    storage: storage,
    limits: {
        fileSize: 1024 * 1024,
        files: 3
    },
    fileFilter: fileFilter
});

// Comment Model
const Comment = require('../../models/Comment');
const Place = require('../../models/Place');
// @route GET api/comments
// @desc GET all comments
// @access Public
router.get('/', (req, res) => {
    Comment.find({accepted: true })
        .sort({ date: -1 })
        .then(comments => res.json(comments));
});


// @route GET api/comments/myrequests
// @desc User's pending comments
// @access Private
router.get('/myrequests', auth, (req, res) => {
    Comment.find({ creatorId: req.user.id  })
        .sort({ accepted: 1 })
        .then(comments => res.json(comments));
});


// @route GET api/comments/admin'
// @desc pending comments
// @access Private
router.get('/admin', auth, (req, res) => {
    if (!req.user.admin) return res.status(400).json({ msg: "You are not an admin,you do not have access!" })
    Comment.find({ accepted: false })
        .sort({ date: 1 })
        .then(comments => res.json(comments));
});


// @route POST api/comments//ccept/:id
// @desc ACCEPT a comment
// @access Private
router.post('/accept/:id', auth, (req, res) => {
    if (!req.user.admin) return res.status(400).json({ msg: "You are not an admin,you do not have access!" })
    Comment.findById(req.params.id)
        .then(comment => {
            if (!comment) return res.status(400).json({ msg: 'Wrong comment ID' })
            comment.accepted = true;
            comment.save().then(() => {
                Place.findById(comment.placeId)
                    .then(place => {
                        if (place.stars === 'undefined') {
                            place.stars = comment.stars
                            place.numberOfComments++;
                        }
                        else {
                            var num = (place.numberOfComments * Number(place.stars));
                            place.numberOfComments++;
                            var average = (num + Number(comment.stars)) / place.numberOfComments;
                            place.stars = String(average);
                        }
                        place.save().then(() => res.json({ success: true }))
                    })
            })
        })
        .catch(err => res.status(404).json({ success: false }))
});

// @route DELETE api/comments/delete/:id
// @desc DELETE a comment
// @access Private
router.delete('/delete/:id', auth, (req, res) => {
    if (!req.user.admin) return res.status(400).json({ msg: "You are not an admin,you do not have access!" })
    Comment.findById(req.params.id)
        .then(comment => {
            if (!comment) return res.status(400).json({ msg: 'Wrong comment ID' })
            comment.remove().then(() => {
                imgs = comment.images;
                imgs.forEach((img) => {
                    const index = img.search("uploads");
                    var del = img.substring(index);
                    fs.unlink(del, (err) => {
                        if (err) return res.status(400).json('Error:' + err)
                    });
                });
                res.json({ success: true })

            })
        })
        .catch(err => res.status(404).json({ success: false }))
});


// @route POST api/comments/create
// @desc Create a comment
// @access Private
router.post('/create', auth, upload.array('images'), (req, res) => {
    const images = req.files.map((file) => {
        return "http://localhost:5000/uploads/" +
            file.filename;
    });

    if (!req.body.title || !req.body.description || images.length === 0 || !req.body.creatorUsername || !req.body.placeId || !req.body.placeName || !req.body.stars ) 
        return res.status(400).json({ msg: 'Please enter all fields' });

    Place.findOne({ _id: req.body.placeId })
        .then(place => {
            if (!place) return res.status(400).json({ msg: 'Wrong place ID' })
            const newComment = new Comment({
                title: req.body.title,
                description: req.body.description,
                images: images,
                stars: req.body.stars,
                creatorId: req.user.id,
                creatorUsername: req.body.creatorUsername,
                placeId: req.body.placeId,
                placeName: req.body.placeName
            })

            newComment.save().then(comment => res.json(comment));
        })

});




module.exports = router;