const express = require('express');
const router = express.Router();
const auth = require('../../middleware/auth');

// Category Model
const Category = require('../../models/Category');

// @route GET api/categories
// @desc GET All Categories
// @access Public
router.get('/', (req, res) => {
    Category.find()
        .sort({ date: -1 })
        .then(categories => res.json(categories));
});

// @route POST api/categories
// @desc Create a category
// @access Private
router.post('/', auth, (req, res) => {
    const name = req.body.name;
    const name1 = new RegExp(["^", name, "$"].join(""), "i");
    if (!req.body.name)
        return res.status(400).json({ msg: 'Please enter all fields' });
    //Check for existing category
    if (!req.user.admin) return res.status(400).json({ msg: "You are not an admin,you do not have access!" })
    Category.findOne({ name:name1 })
        .then(category => {
            if (category) return res.status(400).json({ msg: 'Category already exists' })
            const newCategory = new Category({
                name: name
            });

            newCategory.save().then(category => res.json(category));
        });
});




module.exports = router;