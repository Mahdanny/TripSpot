const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const config = require('config');
const jwt = require('jsonwebtoken');


// User Model
const User = require('../../models/User');

// @route POST api/users
// @desc Register new user
// @access Public
router.post('/', (req, res) => {
    const username = req.body.username;
    const email = req.body.email;
    const email1 = new RegExp(["^", email, "$"].join(""), "i");
    const username1 = new RegExp(["^", username, "$"].join(""), "i");
    const password = req.body.password;
    const name = req.body.name;
    const surname = req.body.surname;

    if (!email || !password || !username || !name || !surname) {
        return res.status(400).json({ msg: 'Please enter all fields' });
    }

    if (password.length < 6 || password.search(/[a-zA-z]/) == -1 || password.search(/[0-9]/) == -1) {
        return res.status(400).json({ msg: "Password must contain at least one letter, one number and more than 6 characters" });
    }
    //Check for existing user
    User.findOne({ email1 })
        .then(user => {
            if (user) return res.status(400).json({ msg: 'Email already exists' })
            User.findOne({ username1 })
                .then(user => {
                    if (user) return res.status(400).json({ msg: 'User already exists' })
                    const newUser = new User({
                        username,
                        email,
                        password,
                        name,
                        surname
                    });

                    // Create salt & hash
                    bcrypt.genSalt(10, (err, salt) => {
                        bcrypt.hash(newUser.password, salt, (err, hash) => {
                            if (err) throw err;
                            newUser.password = hash;
                            newUser.save()
                                .then(user => {
                                    jwt.sign(
                                        { id: user.id,admin:user.admin },
                                        config.get('jwtSecret'),
                                        //{ expiresIn: 3600 },
                                        (err, token) => {
                                            if (err) throw err;
                                            res.json({
                                                token,
                                                user: {
                                                    id: user.id,
                                                    username: user.username,
                                                    email: user.email,
                                                    name: user.name,
                                                    surname: user.surname,
                                                    admin: user.admin
                                                }
                                            });
                                        }
                                    )
                                });
                        })
                    })
                })
        })


});


module.exports = router;