const express = require('express');
const router = express.Router();
const auth = require('../../middleware/auth');

// Message Model
const Message = require('../../models/Message');
// User Model
const User = require('../../models/User');


// @route POST api/messages
// @desc Create a message
// @access Private
router.post('/', auth, (req, res) => {
    const query = { username: new RegExp(["^", req.body.receiverUsername, "$"].join(""), "i") }

    if (!req.body.title || !req.body.message || !req.body.senderUsername || !req.body.receiverUsername )
        return res.status(400).json({ msg: 'Please enter all fields' });
    User.findOne(query)
        .then(user => {
            if (!user) return res.status(400).json({ msg: 'User does not exists' })

            const newMessage = new Message({
                title: req.body.title,
                message: req.body.message,
                receiverUsername: user.username,
                senderUsername: req.body.senderUsername,
                receiverId: user._id,
                senderId: req.user.id
            })
            newMessage.save().then(message => res.json(message));
        });
});

// @route GET api/messages
// @desc GET All messages
// @access Private
router.get('/', auth, (req, res) => {

    Message.find({ $or: [{ receiverId: req.user.id }, { senderId: req.user.id }] })
        .sort({ date: -1 })
        .then(messages => res.json(messages));
});

module.exports = router;