const Place = require('./models/Place');

function rankingsTimer() {
    var avg = 0
    var num = 0
    Place.find({ numberOfComments: { $gte: 1 } })
        .then(places => {
            if (places.length === 0) return
            places.forEach(place => {
                num = num + place.numberOfComments
                avg = avg + parseFloat(place.stars) * place.numberOfComments
            })
            // avg = avg / num
            places.forEach(place => {
                place.ranking = (avg / places.length + place.numberOfComments * parseFloat(place.stars)) / (num / places.length + place.numberOfComments)
                place.save()
            });
        })
};
module.exports = rankingsTimer;